#!/usr/bin/env python3
import argparse
import gzip
import json
import math
import os
from datetime import datetime, timezone
from glob import glob

import pandas as pd
import pysam
from Bio import SeqIO, pairwise2


GENES = ["L1", "L2", "E1", "E2", "E6", "E7", "LCR"]


def abs_path(path):
    if path is None:
        return None
    return os.path.abspath(os.path.expanduser(str(path)))


def normalize_hpv_type(text):
    if text is None:
        return ""
    value = str(text).strip()
    if not value:
        return ""
    value = value.replace("HPV-", "").replace("hpv-", "")
    value = value.replace("HPV_", "").replace("hpv_", "")
    return value.lower()


def load_coordinates(coord_csv):
    df = pd.read_csv(coord_csv)
    virus_col = None
    for candidate in ("Virus", "Type", "HPV_Type", "Reference"):
        if candidate in df.columns:
            virus_col = candidate
            break
    if virus_col is None:
        raise ValueError(f"No virus/type column found in coordinate table: {coord_csv}")

    coords = {}
    for _, row in df.iterrows():
        norm = normalize_hpv_type(row.get(virus_col))
        if not norm:
            continue
        if norm not in coords:
            coords[norm] = {"virus_raw": str(row.get(virus_col, ""))}
        for gene in GENES:
            s_col = f"{gene}_Start"
            e_col = f"{gene}_End"
            if s_col not in df.columns or e_col not in df.columns:
                continue
            try:
                s = int(row[s_col])
                e = int(row[e_col])
            except (ValueError, TypeError):
                continue
            coords[norm][gene] = (s, e)
    return coords


def lookup_gene_coords(all_coords, hpv_type):
    candidates = [
        normalize_hpv_type(hpv_type),
        normalize_hpv_type(str(hpv_type).replace("HPV", "")),
        normalize_hpv_type(str(hpv_type).replace("HPV-", "")),
    ]
    for key in candidates:
        if key in all_coords:
            return all_coords[key]
    return {}


def lookup_l1_coords(all_coords, hpv_type):
    gene_coords = lookup_gene_coords(all_coords, hpv_type)
    start_end = gene_coords.get("L1")
    if not start_end:
        return None, None, None
    return gene_coords.get("virus_raw"), int(start_end[0]), int(start_end[1])


def load_coord_ref_fasta(coord_ref_fasta):
    by_norm = {}
    for rec in SeqIO.parse(coord_ref_fasta, "fasta"):
        rid = str(rec.id).strip()
        seq = str(rec.seq).upper()
        keys = {normalize_hpv_type(rid), normalize_hpv_type(rec.description)}
        for token in str(rec.description).replace("|", " ").replace(",", " ").split():
            keys.add(normalize_hpv_type(token))
        for key in keys:
            if key and key not in by_norm:
                by_norm[key] = (rid, seq)
    return by_norm


def lookup_coord_ref_seq(coord_ref_idx, hpv_type):
    candidates = [
        normalize_hpv_type(hpv_type),
        normalize_hpv_type(str(hpv_type).replace("HPV", "")),
        normalize_hpv_type(str(hpv_type).replace("HPV-", "")),
    ]
    for key in candidates:
        if key in coord_ref_idx:
            return coord_ref_idx[key]
    return None, None


def liftover_interval_by_alignment(coord_seq, sample_seq, ref_start1, ref_end1):
    alignments = pairwise2.align.globalms(coord_seq, sample_seq, 2, -1, -5, -1, one_alignment_only=True)
    if not alignments:
        return {
            "lifted": False,
            "edge_adjusted": False,
            "internal_deletion": False,
            "mapped_ref_bases": 0,
            "deleted_ref_bases": 0,
            "inserted_sample_bases": 0,
            "start": None,
            "end": None,
        }

    aln = alignments[0]
    ref_aln = aln.seqA
    sample_aln = aln.seqB

    ref_pos = 0
    sample_pos = 0
    ref_to_sample = {}
    mapped_ref_bases = 0
    deleted_ref_bases = 0
    inserted_sample_bases = 0

    for ref_base, sample_base in zip(ref_aln, sample_aln):
        if ref_base != "-":
            ref_pos += 1
        if sample_base != "-":
            sample_pos += 1

        if ref_base != "-" and sample_base != "-":
            ref_to_sample[ref_pos] = sample_pos
            if ref_start1 <= ref_pos <= ref_end1:
                mapped_ref_bases += 1
        elif ref_base != "-" and sample_base == "-":
            ref_to_sample[ref_pos] = None
            if ref_start1 <= ref_pos <= ref_end1:
                deleted_ref_bases += 1
        elif ref_base == "-" and sample_base != "-":
            if ref_start1 <= ref_pos <= ref_end1:
                inserted_sample_bases += 1

    edge_adjusted = False
    start = ref_to_sample.get(ref_start1)
    end = ref_to_sample.get(ref_end1)

    if start is None:
        for pos in range(ref_start1, ref_end1 + 1):
            v = ref_to_sample.get(pos)
            if v is not None:
                start = v
                edge_adjusted = True
                break
    if end is None:
        for pos in range(ref_end1, ref_start1 - 1, -1):
            v = ref_to_sample.get(pos)
            if v is not None:
                end = v
                edge_adjusted = True
                break

    lifted = bool(start is not None and end is not None and start <= end)
    return {
        "lifted": lifted,
        "edge_adjusted": edge_adjusted,
        "internal_deletion": deleted_ref_bases > 0,
        "mapped_ref_bases": mapped_ref_bases,
        "deleted_ref_bases": deleted_ref_bases,
        "inserted_sample_bases": inserted_sample_bases,
        "start": int(start) if lifted else None,
        "end": int(end) if lifted else None,
    }


def _maf(af):
    af = float(af)
    return af if af <= 0.5 else (1.0 - af)


def _parse_info(info_str):
    parsed = {}
    for field in info_str.split(";"):
        if "=" in field:
            key, value = field.split("=", 1)
            parsed[key] = value
    return parsed


def _safe_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


def _parse_float_list(text):
    if text is None:
        return []
    values = []
    for token in str(text).split(","):
        token = token.strip()
        if not token:
            continue
        try:
            values.append(float(token))
        except Exception:
            continue
    return values


def _parse_sample_format(parts, dp_from_info):
    afs = []
    dp = dp_from_info
    alt_reads = None
    alt_reads_by_allele = []
    if len(parts) < 10:
        return afs, dp, alt_reads, alt_reads_by_allele

    fmt_keys = parts[8].split(":")
    fmt_vals = parts[9].split(":")
    fmt = {k: fmt_vals[i] for i, k in enumerate(fmt_keys) if i < len(fmt_vals)}

    if dp <= 0 and "DP" in fmt:
        dp = _safe_int(fmt.get("DP"), 0)

    if "AF" in fmt:
        afs = _parse_float_list(fmt.get("AF"))
    elif "AO" in fmt and dp > 0:
        ao = _parse_float_list(fmt.get("AO"))
        afs = [x / dp for x in ao]
        alt_reads = int(sum(ao)) if ao else None
        alt_reads_by_allele = [int(round(x)) for x in ao]
    elif "AD" in fmt and dp > 0:
        ad = _parse_float_list(fmt.get("AD"))
        if len(ad) >= 2:
            alt_counts = ad[1:]
            afs = [x / dp for x in alt_counts]
            alt_reads = int(sum(alt_counts))
            alt_reads_by_allele = [int(round(x)) for x in alt_counts]

    return afs, dp, alt_reads, alt_reads_by_allele


def parse_vcf_robust(
    vcf_path,
    min_maf=0.005,
    max_maf=0.5,
    min_dp=20,
    min_alt_reads=3,
    max_depth=100000,
    snv_only=True,
):
    snv_pos = set()
    pos_best_bin = {}
    site_info = {}
    allele_records = []
    qc_stats = {
        "total": 0,
        "pass": 0,
        "malformed": 0,
        "multi_allelic": 0,
        "non_snv": 0,
        "error_examples": [],
        "file_error": "",
    }

    try:
        handle = gzip.open(vcf_path, "rt", encoding="utf-8", errors="replace") if vcf_path.endswith(".gz") else open(vcf_path, "r", encoding="utf-8", errors="replace")
    except Exception as exc:
        qc_stats["file_error"] = str(exc)
        return snv_pos, pos_best_bin, site_info, allele_records, qc_stats

    with handle:
        for line_num, line in enumerate(handle, start=1):
            if line.startswith("#"):
                continue

            qc_stats["total"] += 1
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 8:
                qc_stats["malformed"] += 1
                if len(qc_stats["error_examples"]) < 5:
                    qc_stats["error_examples"].append(f"line={line_num}: fewer than 8 columns")
                continue

            if parts[6] != "PASS":
                continue

            try:
                pos = int(parts[1])
                ref = parts[3].upper()
                alts = [alt.upper() for alt in parts[4].split(",") if alt]

                if snv_only:
                    if len(ref) != 1 or not alts or any(len(alt) != 1 for alt in alts):
                        qc_stats["non_snv"] += 1
                        continue

                info = _parse_info(parts[7])
                dp = _safe_int(info.get("DP"), 0)
                afs = _parse_float_list(info.get("AF"))
                if len(afs) > 1:
                    qc_stats["multi_allelic"] += 1

                sample_afs, dp, sample_alt_reads, sample_alt_reads_by_allele = _parse_sample_format(parts, dp)
                if not afs:
                    afs = sample_afs

                if dp < min_dp or dp > max_depth:
                    continue

                alt_reads = None
                if "DP4" in info:
                    dp4 = [_safe_int(x, 0) for x in str(info.get("DP4")).split(",") if str(x).strip()]
                    if len(dp4) >= 4:
                        alt_reads = dp4[2] + dp4[3]
                if alt_reads is None:
                    alt_reads = sample_alt_reads
                if alt_reads is not None and alt_reads < min_alt_reads:
                    continue
                if not afs and alt_reads is not None and dp > 0:
                    afs = [alt_reads / float(dp)]

                best_maf = None
                best_bin = None
                pass_alts_all = set()
                pass_alts_bin1 = set()
                pass_alts_bin2 = set()

                for idx, af in enumerate(afs):
                    try:
                        af = float(af)
                    except Exception:
                        continue
                    if af < 0 or af > 1:
                        continue
                    maf = _maf(af)
                    if maf < min_maf or maf > max_maf:
                        continue

                    if idx < len(alts):
                        pass_alts_all.add(alts[idx])
                        if maf <= 0.1:
                            pass_alts_bin1.add(alts[idx])
                        else:
                            pass_alts_bin2.add(alts[idx])
                        per_alt_reads = None
                        reads_is_estimated = True
                        reads_source = "AFxDP_EST"
                        if idx < len(sample_alt_reads_by_allele):
                            per_alt_reads = int(sample_alt_reads_by_allele[idx])
                            reads_is_estimated = False
                            reads_source = "FORMAT_AO_AD"
                        elif dp > 0:
                            per_alt_reads = int(round(af * dp))
                        allele_records.append(
                            {
                                "pos": pos,
                                "ref": ref,
                                "alt": alts[idx],
                                "af": af,
                                "maf": maf,
                                "bin": "bin1" if maf <= 0.1 else "bin2",
                                "dp": dp,
                                "is_multi_site": len(alts) > 1,
                                "alt_reads": per_alt_reads,
                                "alt_reads_is_estimated": reads_is_estimated,
                                "alt_reads_source": reads_source,
                            }
                        )

                    if best_maf is None or maf > best_maf:
                        best_maf = maf
                        best_bin = "bin1" if maf <= 0.1 else "bin2"

                if best_maf is None:
                    continue

                if not pass_alts_all and len(alts) == 1:
                    pass_alts_all.add(alts[0])
                    if best_bin == "bin1":
                        pass_alts_bin1.add(alts[0])
                    else:
                        pass_alts_bin2.add(alts[0])

                snv_pos.add(pos)
                if pos not in pos_best_bin:
                    pos_best_bin[pos] = best_bin
                elif pos_best_bin[pos] == "bin1" and best_bin == "bin2":
                    pos_best_bin[pos] = "bin2"

                current = site_info.get(pos)
                if current is None:
                    site_info[pos] = {
                        "ref": ref,
                        "alts_all": set(pass_alts_all),
                        "alts_bin1": set(pass_alts_bin1),
                        "alts_bin2": set(pass_alts_bin2),
                    }
                else:
                    current["alts_all"].update(pass_alts_all)
                    current["alts_bin1"].update(pass_alts_bin1)
                    current["alts_bin2"].update(pass_alts_bin2)

                qc_stats["pass"] += 1
            except Exception as exc:
                qc_stats["malformed"] += 1
                if len(qc_stats["error_examples"]) < 5:
                    qc_stats["error_examples"].append(f"line={line_num}: {exc}")
                continue
    return snv_pos, pos_best_bin, site_info, allele_records, qc_stats


def _apobec_context(ref_seq, pos1):
    index = pos1 - 1
    if index <= 0 or index >= len(ref_seq) - 1:
        return False, False, False, False
    base = ref_seq[index].upper()
    prev_base = ref_seq[index - 1].upper()
    next_base = ref_seq[index + 1].upper()
    is_c = base == "C"
    is_g = base == "G"
    is_tcw = is_c and prev_base == "T" and next_base in ("A", "T")
    is_wga = is_g and prev_base in ("A", "T") and next_base == "A"
    return is_c, is_g, is_tcw, is_wga


def callable_site_counts(
    bam,
    ref_seq,
    start1,
    end1,
    contig,
    min_depth=20,
    min_bq=20,
    min_mapq=20,
    max_depth=100000,
):
    callable_positions = set()
    c_sites = 0
    g_sites = 0
    tcw_sites = 0
    wga_sites = 0

    region_start = max(0, start1 - 1)
    region_end = min(len(ref_seq), end1)
    for column in bam.pileup(contig=contig, start=region_start, stop=region_end, min_base_quality=min_bq, max_depth=max_depth, truncate=True):
        pos1 = column.pos + 1
        if pos1 < start1 or pos1 > end1:
            continue
        depth = 0
        for pileupread in column.pileups:
            if pileupread.is_del or pileupread.is_refskip or pileupread.query_position is None:
                continue
            if pileupread.alignment.mapping_quality < min_mapq:
                continue
            depth += 1
        if depth < min_depth or depth > max_depth:
            continue

        callable_positions.add(pos1)
        is_c, is_g, is_tcw, is_wga = _apobec_context(ref_seq, pos1)
        if is_c:
            c_sites += 1
            if is_tcw:
                tcw_sites += 1
        if is_g:
            g_sites += 1
            if is_wga:
                wga_sites += 1

    return callable_positions, {
        "Callable_bp": len(callable_positions),
        "C_sites": c_sites,
        "G_sites": g_sites,
        "TCW_sites": tcw_sites,
        "WGA_sites": wga_sites,
    }


def apobec_mut_sites_from_vcf(ref_seq, site_info, callable_pos, start1, end1, maf_bin=None):
    tcw_muts = 0
    wga_muts = 0
    c_muts = 0
    g_muts = 0
    c_apobec_muts = 0
    g_apobec_muts = 0

    alt_key = "alts_all"
    if maf_bin == "bin1":
        alt_key = "alts_bin1"
    elif maf_bin == "bin2":
        alt_key = "alts_bin2"

    for pos1, alleles in site_info.items():
        if pos1 < start1 or pos1 > end1:
            continue
        if pos1 not in callable_pos:
            continue

        ref = str(alleles.get("ref", "")).upper()
        alts = {a.upper() for a in alleles.get(alt_key, set())}
        if not alts:
            continue

        is_c, is_g, is_tcw, is_wga = _apobec_context(ref_seq, pos1)
        if is_c and ref == "C":
            c_muts += 1
            if any(alt in ("T", "G") for alt in alts):
                c_apobec_muts += 1
                if is_tcw:
                    tcw_muts += 1
        if is_g and ref == "G":
            g_muts += 1
            if any(alt in ("A", "C") for alt in alts):
                g_apobec_muts += 1
                if is_wga:
                    wga_muts += 1

    return {
        "TCW_muts": tcw_muts,
        "WGA_muts": wga_muts,
        "C_muts": c_muts,
        "G_muts": g_muts,
        "C_APOBEC_muts": c_apobec_muts,
        "G_APOBEC_muts": g_apobec_muts,
    }


def apobec_2x2_counts(den, muts):
    target_sites = int(den["TCW_sites"] + den["WGA_sites"])
    target_mut_sites = int(muts["TCW_muts"] + muts["WGA_muts"])
    background_sites = int((den["C_sites"] - den["TCW_sites"]) + (den["G_sites"] - den["WGA_sites"]))
    background_mut_sites = int((muts["C_APOBEC_muts"] - muts["TCW_muts"]) + (muts["G_APOBEC_muts"] - muts["WGA_muts"]))

    target_sites = max(target_sites, 0)
    background_sites = max(background_sites, 0)
    target_mut_sites = max(min(target_mut_sites, target_sites), 0)
    background_mut_sites = max(min(background_mut_sites, background_sites), 0)
    return target_sites, target_mut_sites, background_sites, background_mut_sites


def classify_apobec_allele(ref_seq, pos1, ref_base, alt_base):
    is_c, is_g, is_tcw, is_wga = _apobec_context(ref_seq, pos1)
    ref_u = str(ref_base).upper()
    alt_u = str(alt_base).upper()
    is_apobec_change = (is_c and ref_u == "C" and alt_u in ("T", "G")) or (is_g and ref_u == "G" and alt_u in ("A", "C"))
    is_apobec_target = (is_c and is_tcw) or (is_g and is_wga)
    is_apobec = bool(is_apobec_change and is_apobec_target)
    if is_tcw:
        context = "TCW"
    elif is_wga:
        context = "WGA"
    elif is_c:
        context = "C_other"
    elif is_g:
        context = "G_other"
    else:
        context = "Other"
    return context, is_apobec_target, is_apobec_change, is_apobec


def build_allele_rows_for_region(patient_id, sample, hpv_type, region, region_start, region_end, ref_seq, allele_records):
    rows = []
    for record in allele_records:
        pos1 = int(record["pos"])
        if pos1 < region_start or pos1 > region_end:
            continue
        context, is_target_ctx, is_apobec_change, is_apobec = classify_apobec_allele(ref_seq, pos1, record["ref"], record["alt"])
        rows.append(
            {
                "PatientID": patient_id,
                "Sample": sample,
                "Type": hpv_type,
                "Region": region,
                "POS": pos1,
                "REF": record["ref"],
                "ALT": record["alt"],
                "DP": record["dp"],
                "AF": round(float(record["af"]), 6),
                "MAF": round(float(record["maf"]), 6),
                "MAF_Bin": record["bin"],
                "IsMultiAllelicSite": bool(record["is_multi_site"]),
                "AltReads": record["alt_reads"],
                "AltReadsEstimated": bool(record["alt_reads_is_estimated"]),
                "AltReadsSource": record["alt_reads_source"],
                "Context": context,
                "IsAPOBECTargetContext": bool(is_target_ctx),
                "IsAPOBECChange": bool(is_apobec_change),
                "IsAPOBEC": bool(is_apobec),
            }
        )
    return rows


def summarize_multi_allelic(allele_rows):
    grouped = {}
    for row in allele_rows:
        key = (row["PatientID"], row["Sample"], row["Type"], row["Region"])
        if key not in grouped:
            grouped[key] = {
                "multi_sites": set(),
                "multi_sites_with_apobec": set(),
                "multi_alleles": 0,
                "multi_apobec_alleles": 0,
                "af_total": 0.0,
                "af_apobec": 0.0,
                "reads_total": 0.0,
                "reads_apobec": 0.0,
                "af_total_bin1": 0.0,
                "af_apobec_bin1": 0.0,
                "af_total_bin2": 0.0,
                "af_apobec_bin2": 0.0,
                "reads_total_bin1": 0.0,
                "reads_apobec_bin1": 0.0,
                "reads_total_bin2": 0.0,
                "reads_apobec_bin2": 0.0,
            }
        if not row["IsMultiAllelicSite"]:
            continue
        bucket = grouped[key]
        pos = int(row["POS"])
        bucket["multi_sites"].add(pos)
        bucket["multi_alleles"] += 1
        af = float(row["AF"]) if row["AF"] is not None else 0.0
        bucket["af_total"] += af
        alt_reads = row.get("AltReads")
        if alt_reads is not None:
            bucket["reads_total"] += float(alt_reads)
        maf_bin = row.get("MAF_Bin")
        if maf_bin == "bin1":
            bucket["af_total_bin1"] += af
            if alt_reads is not None:
                bucket["reads_total_bin1"] += float(alt_reads)
        elif maf_bin == "bin2":
            bucket["af_total_bin2"] += af
            if alt_reads is not None:
                bucket["reads_total_bin2"] += float(alt_reads)
        if row["IsAPOBEC"]:
            bucket["multi_sites_with_apobec"].add(pos)
            bucket["multi_apobec_alleles"] += 1
            bucket["af_apobec"] += af
            if alt_reads is not None:
                bucket["reads_apobec"] += float(alt_reads)
            if maf_bin == "bin1":
                bucket["af_apobec_bin1"] += af
                if alt_reads is not None:
                    bucket["reads_apobec_bin1"] += float(alt_reads)
            elif maf_bin == "bin2":
                bucket["af_apobec_bin2"] += af
                if alt_reads is not None:
                    bucket["reads_apobec_bin2"] += float(alt_reads)

    summary = []
    for key in sorted(grouped.keys()):
        patient_id, sample, hpv_type, region = key
        bucket = grouped[key]
        af_fraction = (bucket["af_apobec"] / bucket["af_total"]) if bucket["af_total"] > 0 else None
        reads_fraction = (bucket["reads_apobec"] / bucket["reads_total"]) if bucket["reads_total"] > 0 else None
        af_fraction_bin1 = (bucket["af_apobec_bin1"] / bucket["af_total_bin1"]) if bucket["af_total_bin1"] > 0 else None
        af_fraction_bin2 = (bucket["af_apobec_bin2"] / bucket["af_total_bin2"]) if bucket["af_total_bin2"] > 0 else None
        reads_fraction_bin1 = (bucket["reads_apobec_bin1"] / bucket["reads_total_bin1"]) if bucket["reads_total_bin1"] > 0 else None
        reads_fraction_bin2 = (bucket["reads_apobec_bin2"] / bucket["reads_total_bin2"]) if bucket["reads_total_bin2"] > 0 else None
        summary.append(
            {
                "PatientID": patient_id,
                "Sample": sample,
                "Type": hpv_type,
                "Region": region,
                "MultiAltSites": len(bucket["multi_sites"]),
                "MultiAltSites_WithAPOBECAlt": len(bucket["multi_sites_with_apobec"]),
                "MultiAltAlleles": bucket["multi_alleles"],
                "MultiAltAlleles_APOBEC": bucket["multi_apobec_alleles"],
                "APOBEC_AF_Fraction_MultiAllelic": af_fraction,
                "APOBEC_Read_Fraction_MultiAllelic": reads_fraction,
                "APOBEC_AF_Fraction_MultiAllelic_Bin1": af_fraction_bin1,
                "APOBEC_AF_Fraction_MultiAllelic_Bin2": af_fraction_bin2,
                "APOBEC_Read_Fraction_MultiAllelic_Bin1": reads_fraction_bin1,
                "APOBEC_Read_Fraction_MultiAllelic_Bin2": reads_fraction_bin2,
            }
        )
    return summary


def enrichment_odds_ratio(target_sites, target_mut_sites, background_sites, background_mut_sites, pseudocount=0.5):
    a = target_mut_sites
    b = target_sites - target_mut_sites
    c = background_mut_sites
    d = background_sites - background_mut_sites
    return ((a + pseudocount) / (b + pseudocount)) / ((c + pseudocount) / (d + pseudocount))


def fisher_exact_greater(a, b, c, d):
    a = int(a)
    b = int(b)
    c = int(c)
    d = int(d)
    if min(a, b, c, d) < 0:
        return 1.0

    n1 = a + b
    n2 = c + d
    k = a + c
    n = n1 + n2
    if n == 0:
        return 1.0

    lo = max(0, k - n2)
    hi = min(k, n1)
    if a > hi:
        return 1.0
    if a < lo:
        a = lo

    def log_comb(nn, rr):
        return math.lgamma(nn + 1) - math.lgamma(rr + 1) - math.lgamma(nn - rr + 1)

    def log_pmf(x):
        return log_comb(n1, x) + log_comb(n2, k - x) - log_comb(n, k)

    tail = [log_pmf(x) for x in range(a, hi + 1)]
    peak = max(tail)
    return float(sum(math.exp(x - peak) for x in tail) * math.exp(peak))


def benjamini_hochberg(p_values):
    n = len(p_values)
    if n == 0:
        return []

    indexed = sorted(enumerate(p_values), key=lambda x: x[1])
    q_values = [1.0] * n
    running = 1.0
    for rank in range(n, 0, -1):
        idx, pval = indexed[rank - 1]
        q = min(running, (pval * n) / rank)
        running = q
        q_values[idx] = q
    return q_values


def power_reasons(callable_bp, callable_frac, target_sites, background_sites, total_mut_sites, rules):
    reasons = []
    if callable_bp < rules["callable_bp"]:
        reasons.append(f"callable_bp<{rules['callable_bp']}")
    if callable_frac < rules["callable_frac"]:
        reasons.append(f"callable_frac<{rules['callable_frac']}")
    if target_sites < rules["target_sites"]:
        reasons.append(f"target_sites<{rules['target_sites']}")
    if background_sites < rules["background_sites"]:
        reasons.append(f"background_sites<{rules['background_sites']}")
    if total_mut_sites < rules["total_mut_sites"]:
        reasons.append(f"total_mut_sites<{rules['total_mut_sites']}")
    return reasons


def build_run_config(args, run_utc):
    return {
        "analysis_version": "V10-WG-L1",
        "run_utc": run_utc,
        "region": "WG+L1",
        "patient_id": str(args.patient_id),
        "patient_root": os.path.abspath(args.patient_root),
        "coord_db": os.path.abspath(args.coord_db),
        "coord_ref_fasta": os.path.abspath(args.coord_ref_fasta),
        "write_allele_tables": bool(int(args.write_allele_tables)),
        "maf_bins": ["MAF[0.005, 0.1]", "MAF(0.1, 0.5]"],
        "vcf_snv_only": True,
        "vcf_maf_min": args.vcf_maf_min,
        "vcf_maf_max": args.vcf_maf_max,
        "vcf_min_dp": args.vcf_min_dp,
        "vcf_min_alt_reads": args.vcf_min_alt_reads,
        "pileup_min_depth": args.pileup_min_depth,
        "pileup_min_bq": args.pileup_min_bq,
        "pileup_min_mapq": args.pileup_min_mapq,
        "pileup_max_depth": args.pileup_max_depth,
        "wg_strain_power": {
            "callable_bp": args.strain_min_callable_bp,
            "callable_frac": args.strain_min_callable_frac,
            "target_sites": args.strain_min_target_sites,
            "background_sites": args.strain_min_background_sites,
            "total_mut_sites": args.strain_min_total_mut_sites,
        },
        "wg_gene_power": {
            "callable_bp": args.gene_min_callable_bp,
            "callable_frac": args.gene_min_callable_frac,
            "target_sites": args.gene_min_target_sites,
            "background_sites": args.gene_min_background_sites,
            "total_mut_sites": args.gene_min_total_mut_sites,
        },
        "l1_power": {
            "callable_bp": args.l1_min_callable_bp,
            "callable_frac": args.l1_min_callable_frac,
            "target_sites": args.l1_min_target_sites,
            "background_sites": args.l1_min_background_sites,
            "total_mut_sites": args.l1_min_total_mut_sites,
        },
    }


def init_l1_missing(row, reason):
    row["L1_CoordRef_Type"] = None
    row["L1_CoordRef_Start"] = None
    row["L1_CoordRef_End"] = None
    row["L1_CoordMappedRefBases"] = None
    row["L1_CoordDeletedRefBases"] = None
    row["L1_CoordInsertedSampleBases"] = None
    row["L1_CoordInternalDeletion"] = None
    row["L1_CoordLifted"] = False
    row["L1_CoordEdgeAdjusted"] = None
    row["L1_Start"] = None
    row["L1_End"] = None
    row["L1_SNVs"] = 0
    row["L1_iSNVs_Bin1_Label"] = "MAF[0.005, 0.1]"
    row["L1_iSNVs_maf_0.005_0.1"] = 0
    row["L1_iSNVs_Bin2_Label"] = "MAF(0.1, 0.5]"
    row["L1_iSNVs_maf_0.1_0.5"] = 0
    row["L1_Len"] = None
    row["L1_Density"] = None
    row["L1_Callable_bp"] = None
    row["L1_Callable_frac"] = None
    row["L1_Density_Callable"] = None
    row["L1_TargetSites"] = None
    row["L1_TargetMutSites"] = None
    row["L1_BackgroundSites"] = None
    row["L1_BackgroundMutSites"] = None
    row["L1_Fisher_p"] = None
    row["L1_FDR"] = None
    row["L1_LOW_POWER"] = True
    row["L1_LOW_POWER_REASON"] = reason
    row["L1_APOBEC_Enrichment"] = None
    row["L1_TargetMutSites_maf_0.005_0.1"] = None
    row["L1_BackgroundMutSites_maf_0.005_0.1"] = None
    row["L1_Fisher_p_maf_0.005_0.1"] = None
    row["L1_FDR_maf_0.005_0.1"] = None
    row["L1_APOBEC_Enrichment_maf_0.005_0.1"] = None
    row["L1_TargetMutSites_maf_0.1_0.5"] = None
    row["L1_BackgroundMutSites_maf_0.1_0.5"] = None
    row["L1_Fisher_p_maf_0.1_0.5"] = None
    row["L1_FDR_maf_0.1_0.5"] = None
    row["L1_APOBEC_Enrichment_maf_0.1_0.5"] = None
    row["L1_APOBEC_TCW_MutSites"] = None
    row["L1_APOBEC_TCW_Sites"] = None
    row["L1_APOBEC_WGA_MutSites"] = None
    row["L1_APOBEC_WGA_Sites"] = None
    row["L1_APOBEC_C_MutSites"] = None
    row["L1_APOBEC_C_APOBEC_MutSites"] = None
    row["L1_APOBEC_C_Sites"] = None
    row["L1_APOBEC_G_MutSites"] = None
    row["L1_APOBEC_G_APOBEC_MutSites"] = None
    row["L1_APOBEC_G_Sites"] = None


def analyze_strain(folder_path, patient_id, all_coords, coord_ref_idx, run_config, args):
    folder_name = os.path.basename(folder_path)
    try:
        sample, hpv_type = folder_name.split("_", 1)
    except ValueError:
        return None, {"Folder": folder_name, "Reason": "invalid_folder_name"}, []

    bam_path = os.path.join(folder_path, "remap_consensus.bam")
    ref_path = os.path.join(folder_path, "consensus_wg.fa")
    vcf_path = os.path.join(folder_path, "lofreq.filtered.vcf")
    missing = [path for path in (bam_path, ref_path, vcf_path) if not os.path.exists(path)]
    if missing:
        return None, {"Folder": folder_name, "Reason": "missing_required_files", "Detail": ";".join(missing)}, []

    row = {
        "AnalysisVersion": "V10-WG-L1",
        "RunUTC": run_config["run_utc"],
        "RunConfigJSON": json.dumps(run_config, separators=(",", ":"), sort_keys=True),
        "PatientID": patient_id,
        "Sample": sample,
        "Type": hpv_type,
        "WG_iSNVs_Bin1_Label": "MAF[0.005, 0.1]",
        "WG_iSNVs_Bin2_Label": "MAF(0.1, 0.5]",
        "Notes": "",
    }

    snv_pos, pos_best_bin, site_info, allele_records, qc = parse_vcf_robust(
        vcf_path,
        min_maf=args.vcf_maf_min,
        max_maf=args.vcf_maf_max,
        min_dp=args.vcf_min_dp,
        min_alt_reads=args.vcf_min_alt_reads,
        max_depth=args.pileup_max_depth,
        snv_only=True,
    )
    row["QC_Total_VCF"] = qc["total"]
    row["QC_Pass_VCF"] = qc["pass"]
    row["QC_Malformed_VCF"] = qc["malformed"]
    row["QC_MultiAllelic_VCF"] = qc["multi_allelic"]
    row["QC_NonSNV_VCF"] = qc["non_snv"]
    row["QC_VCF_ErrorExamples"] = ";".join(qc["error_examples"]) if qc["error_examples"] else ""
    row["QC_VCF_FileError"] = qc["file_error"]

    row["WG_SNVs"] = len(snv_pos)
    row["WG_iSNVs_maf_0.005_0.1"] = sum(1 for p in snv_pos if pos_best_bin.get(p) == "bin1")
    row["WG_iSNVs_maf_0.1_0.5"] = sum(1 for p in snv_pos if pos_best_bin.get(p) == "bin2")

    try:
        ref_rec = SeqIO.read(ref_path, "fasta")
        ref_seq = str(ref_rec.seq).upper()
        ref_id = ref_rec.id
    except Exception as exc:
        return None, {"Folder": folder_name, "Reason": "fasta_read_failed", "Detail": str(exc)}, []
    allele_rows = build_allele_rows_for_region(patient_id, sample, hpv_type, "WG", 1, len(ref_seq), ref_seq, allele_records)

    row["WG_Len"] = len(ref_seq)
    row["WG_Density"] = round((len(snv_pos) / (len(ref_seq) / 1000.0)), 3) if len(ref_seq) > 0 else 0.0

    try:
        bam = pysam.AlignmentFile(bam_path, "rb")
    except Exception as exc:
        return None, {"Folder": folder_name, "Reason": "bam_open_failed", "Detail": str(exc)}, []

    try:
        contig = ref_id if ref_id in set(bam.references) else (bam.references[0] if bam.references else None)
        if contig is None:
            return None, {"Folder": folder_name, "Reason": "bam_has_no_references"}, []

        callable_pos_wg, den_wg = callable_site_counts(
            bam,
            ref_seq,
            1,
            len(ref_seq),
            contig,
            min_depth=args.pileup_min_depth,
            min_bq=args.pileup_min_bq,
            min_mapq=args.pileup_min_mapq,
            max_depth=args.pileup_max_depth,
        )
        callable_bp = den_wg["Callable_bp"]
        callable_frac = (callable_bp / float(len(ref_seq))) if len(ref_seq) > 0 else 0.0
        row["WG_Callable_bp"] = callable_bp
        row["WG_Callable_frac"] = round(callable_frac, 3)
        row["WG_Density_Callable"] = round((len(snv_pos) / (callable_bp / 1000.0)), 3) if callable_bp > 0 else None

        muts_wg = apobec_mut_sites_from_vcf(ref_seq, site_info, callable_pos_wg, 1, len(ref_seq), maf_bin=None)
        target_sites, target_muts, background_sites, background_muts = apobec_2x2_counts(den_wg, muts_wg)

        row["TargetSites"] = target_sites
        row["TargetMutSites"] = target_muts
        row["BackgroundSites"] = background_sites
        row["BackgroundMutSites"] = background_muts
        row["WG_APOBEC_TCW_MutSites"] = muts_wg["TCW_muts"]
        row["WG_APOBEC_TCW_Sites"] = den_wg["TCW_sites"]
        row["WG_APOBEC_WGA_MutSites"] = muts_wg["WGA_muts"]
        row["WG_APOBEC_WGA_Sites"] = den_wg["WGA_sites"]
        row["WG_APOBEC_C_MutSites"] = muts_wg["C_muts"]
        row["WG_APOBEC_C_APOBEC_MutSites"] = muts_wg["C_APOBEC_muts"]
        row["WG_APOBEC_C_Sites"] = den_wg["C_sites"]
        row["WG_APOBEC_G_MutSites"] = muts_wg["G_muts"]
        row["WG_APOBEC_G_APOBEC_MutSites"] = muts_wg["G_APOBEC_muts"]
        row["WG_APOBEC_G_Sites"] = den_wg["G_sites"]

        strain_reasons = power_reasons(
            callable_bp=callable_bp,
            callable_frac=callable_frac,
            target_sites=target_sites,
            background_sites=background_sites,
            total_mut_sites=(target_muts + background_muts),
            rules=run_config["wg_strain_power"],
        )
        row["LOW_POWER"] = bool(strain_reasons)
        row["LOW_POWER_REASON"] = ";".join(strain_reasons)

        if row["LOW_POWER"]:
            row["WG_APOBEC_Enrichment"] = None
            row["Fisher_p"] = None
            row["FDR"] = None
        else:
            row["WG_APOBEC_Enrichment"] = round(enrichment_odds_ratio(target_sites, target_muts, background_sites, background_muts), 2)
            row["Fisher_p"] = fisher_exact_greater(target_muts, target_sites - target_muts, background_muts, background_sites - background_muts) if (target_sites > 0 and background_sites > 0) else None
            row["FDR"] = None

        gene_coords = lookup_gene_coords(all_coords, hpv_type)
        notes = []
        for gene in GENES:
            prefix = f"{gene}_"
            start_end = gene_coords.get(gene)
            if not start_end:
                row[f"{prefix}SNVs"] = 0
                row[f"{prefix}Density"] = 0.0
                row[f"{prefix}Callable_bp"] = 0
                row[f"{prefix}Density_Callable"] = None
                row[f"{prefix}TargetSites"] = 0
                row[f"{prefix}TargetMutSites"] = 0
                row[f"{prefix}BackgroundSites"] = 0
                row[f"{prefix}BackgroundMutSites"] = 0
                row[f"{prefix}APOBEC"] = None
                row[f"{prefix}Fisher_p"] = None
                row[f"{prefix}FDR"] = None
                row[f"{prefix}LOW_POWER"] = True
                rs = ["missing_gene_coordinates"]
                if row["LOW_POWER"]:
                    rs.insert(0, "strain_low_power")
                row[f"{prefix}LOW_POWER_REASON"] = ";".join(rs)
                continue

            start1, end1 = int(start_end[0]), int(start_end[1])
            start1 = max(1, start1)
            end1 = min(len(ref_seq), end1)
            if end1 < start1:
                row[f"{prefix}SNVs"] = 0
                row[f"{prefix}Density"] = 0.0
                row[f"{prefix}Callable_bp"] = 0
                row[f"{prefix}Density_Callable"] = None
                row[f"{prefix}TargetSites"] = 0
                row[f"{prefix}TargetMutSites"] = 0
                row[f"{prefix}BackgroundSites"] = 0
                row[f"{prefix}BackgroundMutSites"] = 0
                row[f"{prefix}APOBEC"] = None
                row[f"{prefix}Fisher_p"] = None
                row[f"{prefix}FDR"] = None
                row[f"{prefix}LOW_POWER"] = True
                rs = ["invalid_gene_coordinates"]
                if row["LOW_POWER"]:
                    rs.insert(0, "strain_low_power")
                row[f"{prefix}LOW_POWER_REASON"] = ";".join(rs)
                continue

            gene_len = end1 - start1 + 1
            gene_snv = sum(1 for p in snv_pos if start1 <= p <= end1)
            gene_density = round((gene_snv / (gene_len / 1000.0)), 3) if gene_len > 0 else 0.0
            row[f"{prefix}SNVs"] = gene_snv
            row[f"{prefix}Density"] = gene_density
            if gene_density > 10.0:
                notes.append(f"CHECK_{gene}_HighDensity")

            callable_pos_gene, den_gene = callable_site_counts(
                bam,
                ref_seq,
                start1,
                end1,
                contig,
                min_depth=args.pileup_min_depth,
                min_bq=args.pileup_min_bq,
                min_mapq=args.pileup_min_mapq,
                max_depth=args.pileup_max_depth,
            )
            callable_bp_gene = den_gene["Callable_bp"]
            callable_frac_gene = (callable_bp_gene / float(gene_len)) if gene_len > 0 else 0.0
            muts_gene = apobec_mut_sites_from_vcf(ref_seq, site_info, callable_pos_gene, start1, end1, maf_bin=None)
            ts, tm, bs, bm = apobec_2x2_counts(den_gene, muts_gene)

            row[f"{prefix}Callable_bp"] = callable_bp_gene
            row[f"{prefix}Density_Callable"] = round((gene_snv / (callable_bp_gene / 1000.0)), 3) if callable_bp_gene > 0 else None
            row[f"{prefix}TargetSites"] = ts
            row[f"{prefix}TargetMutSites"] = tm
            row[f"{prefix}BackgroundSites"] = bs
            row[f"{prefix}BackgroundMutSites"] = bm

            gene_reasons = power_reasons(
                callable_bp=callable_bp_gene,
                callable_frac=callable_frac_gene,
                target_sites=ts,
                background_sites=bs,
                total_mut_sites=(tm + bm),
                rules=run_config["wg_gene_power"],
            )
            if row["LOW_POWER"]:
                gene_reasons.insert(0, "strain_low_power")
            row[f"{prefix}LOW_POWER"] = bool(gene_reasons)
            row[f"{prefix}LOW_POWER_REASON"] = ";".join(gene_reasons)

            if row[f"{prefix}LOW_POWER"]:
                row[f"{prefix}APOBEC"] = None
                row[f"{prefix}Fisher_p"] = None
                row[f"{prefix}FDR"] = None
            else:
                row[f"{prefix}APOBEC"] = round(enrichment_odds_ratio(ts, tm, bs, bm), 2) if ts > 0 and bs > 0 else None
                row[f"{prefix}Fisher_p"] = fisher_exact_greater(tm, ts - tm, bm, bs - bm) if ts > 0 and bs > 0 else None
                row[f"{prefix}FDR"] = None

        row["Notes"] = ";".join(notes) + (";" if notes else "")

        coord_ref_type, l1_ref_start, l1_ref_end = lookup_l1_coords(all_coords, hpv_type)
        if l1_ref_start is None or l1_ref_end is None:
            init_l1_missing(row, "missing_l1_coordinates")
        else:
            coord_ref_id, coord_ref_seq = lookup_coord_ref_seq(coord_ref_idx, hpv_type)
            if coord_ref_seq is None:
                init_l1_missing(row, "missing_coord_ref_sequence")
            else:
                lift = liftover_interval_by_alignment(coord_ref_seq, ref_seq, l1_ref_start, l1_ref_end)
                row["L1_CoordRef_Type"] = coord_ref_type if coord_ref_type is not None else coord_ref_id
                row["L1_CoordRef_Start"] = l1_ref_start
                row["L1_CoordRef_End"] = l1_ref_end
                row["L1_CoordMappedRefBases"] = lift["mapped_ref_bases"]
                row["L1_CoordDeletedRefBases"] = lift["deleted_ref_bases"]
                row["L1_CoordInsertedSampleBases"] = lift["inserted_sample_bases"]
                row["L1_CoordInternalDeletion"] = bool(lift["internal_deletion"])
                row["L1_CoordLifted"] = bool(lift["lifted"])
                row["L1_CoordEdgeAdjusted"] = bool(lift["edge_adjusted"])
                row["L1_Start"] = lift["start"]
                row["L1_End"] = lift["end"]

                if not lift["lifted"]:
                    init_l1_missing(row, "l1_liftover_failed")
                    row["L1_CoordRef_Type"] = coord_ref_type if coord_ref_type is not None else coord_ref_id
                    row["L1_CoordRef_Start"] = l1_ref_start
                    row["L1_CoordRef_End"] = l1_ref_end
                else:
                    l1_start = int(lift["start"])
                    l1_end = int(lift["end"])
                    l1_len = max(0, l1_end - l1_start + 1)
                    row["L1_Len"] = l1_len
                    allele_rows.extend(build_allele_rows_for_region(patient_id, sample, hpv_type, "L1", l1_start, l1_end, ref_seq, allele_records))
                    l1_snv = [p for p in snv_pos if l1_start <= p <= l1_end]
                    row["L1_SNVs"] = len(l1_snv)
                    row["L1_iSNVs_Bin1_Label"] = "MAF[0.005, 0.1]"
                    row["L1_iSNVs_maf_0.005_0.1"] = sum(1 for p in l1_snv if pos_best_bin.get(p) == "bin1")
                    row["L1_iSNVs_Bin2_Label"] = "MAF(0.1, 0.5]"
                    row["L1_iSNVs_maf_0.1_0.5"] = sum(1 for p in l1_snv if pos_best_bin.get(p) == "bin2")
                    row["L1_Density"] = round((len(l1_snv) / (l1_len / 1000.0)), 3) if l1_len > 0 else 0.0

                    if l1_len <= 0:
                        init_l1_missing(row, "invalid_l1_interval")
                    else:
                        callable_pos_l1, den_l1 = callable_site_counts(
                            bam,
                            ref_seq,
                            l1_start,
                            l1_end,
                            contig,
                            min_depth=args.pileup_min_depth,
                            min_bq=args.pileup_min_bq,
                            min_mapq=args.pileup_min_mapq,
                            max_depth=args.pileup_max_depth,
                        )
                        l1_callable_bp = den_l1["Callable_bp"]
                        l1_callable_frac = l1_callable_bp / float(l1_len) if l1_len > 0 else 0.0
                        row["L1_Callable_bp"] = l1_callable_bp
                        row["L1_Callable_frac"] = round(l1_callable_frac, 3)
                        row["L1_Density_Callable"] = round((len(l1_snv) / (l1_callable_bp / 1000.0)), 3) if l1_callable_bp > 0 else None

                        muts_l1 = apobec_mut_sites_from_vcf(ref_seq, site_info, callable_pos_l1, l1_start, l1_end, maf_bin=None)
                        ts, tm, bs, bm = apobec_2x2_counts(den_l1, muts_l1)
                        row["L1_TargetSites"] = ts
                        row["L1_TargetMutSites"] = tm
                        row["L1_BackgroundSites"] = bs
                        row["L1_BackgroundMutSites"] = bm

                        muts_l1_bin1 = apobec_mut_sites_from_vcf(ref_seq, site_info, callable_pos_l1, l1_start, l1_end, maf_bin="bin1")
                        _, tm1, _, bm1 = apobec_2x2_counts(den_l1, muts_l1_bin1)
                        row["L1_TargetMutSites_maf_0.005_0.1"] = tm1
                        row["L1_BackgroundMutSites_maf_0.005_0.1"] = bm1

                        muts_l1_bin2 = apobec_mut_sites_from_vcf(ref_seq, site_info, callable_pos_l1, l1_start, l1_end, maf_bin="bin2")
                        _, tm2, _, bm2 = apobec_2x2_counts(den_l1, muts_l1_bin2)
                        row["L1_TargetMutSites_maf_0.1_0.5"] = tm2
                        row["L1_BackgroundMutSites_maf_0.1_0.5"] = bm2

                        row["L1_APOBEC_TCW_MutSites"] = muts_l1["TCW_muts"]
                        row["L1_APOBEC_TCW_Sites"] = den_l1["TCW_sites"]
                        row["L1_APOBEC_WGA_MutSites"] = muts_l1["WGA_muts"]
                        row["L1_APOBEC_WGA_Sites"] = den_l1["WGA_sites"]
                        row["L1_APOBEC_C_MutSites"] = muts_l1["C_muts"]
                        row["L1_APOBEC_C_APOBEC_MutSites"] = muts_l1["C_APOBEC_muts"]
                        row["L1_APOBEC_C_Sites"] = den_l1["C_sites"]
                        row["L1_APOBEC_G_MutSites"] = muts_l1["G_muts"]
                        row["L1_APOBEC_G_APOBEC_MutSites"] = muts_l1["G_APOBEC_muts"]
                        row["L1_APOBEC_G_Sites"] = den_l1["G_sites"]

                        l1_reasons = power_reasons(
                            callable_bp=l1_callable_bp,
                            callable_frac=l1_callable_frac,
                            target_sites=ts,
                            background_sites=bs,
                            total_mut_sites=(tm + bm),
                            rules=run_config["l1_power"],
                        )
                        row["L1_LOW_POWER"] = bool(l1_reasons)
                        row["L1_LOW_POWER_REASON"] = ";".join(l1_reasons)

                        if row["L1_Density"] is not None and row["L1_Density"] > 10.0 and "CHECK_L1_HighDensity;" not in row["Notes"]:
                            row["Notes"] += "CHECK_L1_HighDensity;"

                        if row["L1_LOW_POWER"]:
                            row["L1_APOBEC_Enrichment"] = None
                            row["L1_Fisher_p"] = None
                            row["L1_FDR"] = None
                            row["L1_Fisher_p_maf_0.005_0.1"] = None
                            row["L1_FDR_maf_0.005_0.1"] = None
                            row["L1_APOBEC_Enrichment_maf_0.005_0.1"] = None
                            row["L1_Fisher_p_maf_0.1_0.5"] = None
                            row["L1_FDR_maf_0.1_0.5"] = None
                            row["L1_APOBEC_Enrichment_maf_0.1_0.5"] = None
                        else:
                            row["L1_APOBEC_Enrichment"] = round(enrichment_odds_ratio(ts, tm, bs, bm), 2) if ts > 0 and bs > 0 else None
                            row["L1_Fisher_p"] = fisher_exact_greater(tm, ts - tm, bm, bs - bm) if ts > 0 and bs > 0 else None
                            row["L1_FDR"] = None
                            row["L1_APOBEC_Enrichment_maf_0.005_0.1"] = round(enrichment_odds_ratio(ts, tm1, bs, bm1), 2) if ts > 0 and bs > 0 else None
                            row["L1_Fisher_p_maf_0.005_0.1"] = fisher_exact_greater(tm1, ts - tm1, bm1, bs - bm1) if ts > 0 and bs > 0 else None
                            row["L1_FDR_maf_0.005_0.1"] = None
                            row["L1_APOBEC_Enrichment_maf_0.1_0.5"] = round(enrichment_odds_ratio(ts, tm2, bs, bm2), 2) if ts > 0 and bs > 0 else None
                            row["L1_Fisher_p_maf_0.1_0.5"] = fisher_exact_greater(tm2, ts - tm2, bm2, bs - bm2) if ts > 0 and bs > 0 else None
                            row["L1_FDR_maf_0.1_0.5"] = None

        return row, None, allele_rows
    finally:
        bam.close()


def apply_fdr(df):
    wg_idx = []
    wg_p = []
    for idx, row in df.iterrows():
        if bool(row.get("LOW_POWER")):
            continue
        p = row.get("Fisher_p")
        if p is None or p == "" or (isinstance(p, float) and math.isnan(p)):
            continue
        wg_idx.append(idx)
        wg_p.append(float(p))
    for idx, q in zip(wg_idx, benjamini_hochberg(wg_p)):
        df.at[idx, "FDR"] = float(q)

    for gene in GENES:
        p_col = f"{gene}_Fisher_p"
        q_col = f"{gene}_FDR"
        idxs = []
        pvals = []
        for idx, row in df.iterrows():
            if bool(row.get(f"{gene}_LOW_POWER")):
                continue
            p = row.get(p_col)
            if p is None or p == "" or (isinstance(p, float) and math.isnan(p)):
                continue
            idxs.append(idx)
            pvals.append(float(p))
        for idx, q in zip(idxs, benjamini_hochberg(pvals)):
            df.at[idx, q_col] = float(q)

    l1_tests = [
        ("L1_Fisher_p", "L1_FDR"),
        ("L1_Fisher_p_maf_0.005_0.1", "L1_FDR_maf_0.005_0.1"),
        ("L1_Fisher_p_maf_0.1_0.5", "L1_FDR_maf_0.1_0.5"),
    ]
    for p_col, q_col in l1_tests:
        idxs = []
        pvals = []
        for idx, row in df.iterrows():
            if bool(row.get("L1_LOW_POWER")):
                continue
            p = row.get(p_col)
            if p is None or p == "" or (isinstance(p, float) and math.isnan(p)):
                continue
            idxs.append(idx)
            pvals.append(float(p))
        for idx, q in zip(idxs, benjamini_hochberg(pvals)):
            df.at[idx, q_col] = float(q)

    return df


def ordered_columns():
    cols = [
        "AnalysisVersion",
        "RunUTC",
        "RunConfigJSON",
        "PatientID",
        "Sample",
        "Type",
        "WG_SNVs",
        "WG_iSNVs_Bin1_Label",
        "WG_iSNVs_maf_0.005_0.1",
        "WG_iSNVs_Bin2_Label",
        "WG_iSNVs_maf_0.1_0.5",
        "WG_Len",
        "WG_Density",
        "WG_Callable_bp",
        "WG_Callable_frac",
        "WG_Density_Callable",
        "TargetSites",
        "TargetMutSites",
        "BackgroundSites",
        "BackgroundMutSites",
        "Fisher_p",
        "FDR",
        "LOW_POWER",
        "LOW_POWER_REASON",
        "WG_APOBEC_Enrichment",
        "WG_APOBEC_TCW_MutSites",
        "WG_APOBEC_TCW_Sites",
        "WG_APOBEC_WGA_MutSites",
        "WG_APOBEC_WGA_Sites",
        "WG_APOBEC_C_MutSites",
        "WG_APOBEC_C_APOBEC_MutSites",
        "WG_APOBEC_C_Sites",
        "WG_APOBEC_G_MutSites",
        "WG_APOBEC_G_APOBEC_MutSites",
        "WG_APOBEC_G_Sites",
        "Notes",
        "QC_Total_VCF",
        "QC_Pass_VCF",
        "QC_Malformed_VCF",
        "QC_MultiAllelic_VCF",
        "QC_NonSNV_VCF",
        "QC_VCF_ErrorExamples",
        "QC_VCF_FileError",
    ]

    for gene in GENES:
        cols.extend(
            [
                f"{gene}_SNVs",
                f"{gene}_Density",
                f"{gene}_Callable_bp",
                f"{gene}_Density_Callable",
                f"{gene}_TargetSites",
                f"{gene}_TargetMutSites",
                f"{gene}_BackgroundSites",
                f"{gene}_BackgroundMutSites",
                f"{gene}_APOBEC",
                f"{gene}_Fisher_p",
                f"{gene}_FDR",
                f"{gene}_LOW_POWER",
                f"{gene}_LOW_POWER_REASON",
            ]
        )

    cols.extend(
        [
            "L1_CoordRef_Type",
            "L1_CoordRef_Start",
            "L1_CoordRef_End",
            "L1_CoordMappedRefBases",
            "L1_CoordDeletedRefBases",
            "L1_CoordInsertedSampleBases",
            "L1_CoordInternalDeletion",
            "L1_CoordLifted",
            "L1_CoordEdgeAdjusted",
            "L1_Start",
            "L1_End",
            "L1_SNVs",
            "L1_iSNVs_Bin1_Label",
            "L1_iSNVs_maf_0.005_0.1",
            "L1_iSNVs_Bin2_Label",
            "L1_iSNVs_maf_0.1_0.5",
            "L1_Len",
            "L1_Density",
            "L1_Callable_bp",
            "L1_Callable_frac",
            "L1_Density_Callable",
            "L1_TargetSites",
            "L1_TargetMutSites",
            "L1_BackgroundSites",
            "L1_BackgroundMutSites",
            "L1_Fisher_p",
            "L1_FDR",
            "L1_LOW_POWER",
            "L1_LOW_POWER_REASON",
            "L1_APOBEC_Enrichment",
            "L1_TargetMutSites_maf_0.005_0.1",
            "L1_BackgroundMutSites_maf_0.005_0.1",
            "L1_Fisher_p_maf_0.005_0.1",
            "L1_FDR_maf_0.005_0.1",
            "L1_APOBEC_Enrichment_maf_0.005_0.1",
            "L1_TargetMutSites_maf_0.1_0.5",
            "L1_BackgroundMutSites_maf_0.1_0.5",
            "L1_Fisher_p_maf_0.1_0.5",
            "L1_FDR_maf_0.1_0.5",
            "L1_APOBEC_Enrichment_maf_0.1_0.5",
            "L1_APOBEC_TCW_MutSites",
            "L1_APOBEC_TCW_Sites",
            "L1_APOBEC_WGA_MutSites",
            "L1_APOBEC_WGA_Sites",
            "L1_APOBEC_C_MutSites",
            "L1_APOBEC_C_APOBEC_MutSites",
            "L1_APOBEC_C_Sites",
            "L1_APOBEC_G_MutSites",
            "L1_APOBEC_G_APOBEC_MutSites",
            "L1_APOBEC_G_Sites",
        ]
    )
    return cols


def main():
    parser = argparse.ArgumentParser(description="Unified standalone WG+L1 analyzer (one merged output table).")
    parser.add_argument("--patient_id", required=True)
    parser.add_argument("--patient_root", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--allele_out", default=None)
    parser.add_argument("--allele_multi_summary_out", default=None)
    parser.add_argument("--write_allele_tables", type=int, default=1)
    parser.add_argument("--coord_db", required=True)
    parser.add_argument("--coord_ref_fasta", required=True)

    parser.add_argument("--vcf_maf_min", type=float, default=0.005)
    parser.add_argument("--vcf_maf_max", type=float, default=0.5)
    parser.add_argument("--vcf_min_dp", type=int, default=20)
    parser.add_argument("--vcf_min_alt_reads", type=int, default=3)

    parser.add_argument("--pileup_min_depth", type=int, default=20)
    parser.add_argument("--pileup_min_bq", type=int, default=20)
    parser.add_argument("--pileup_min_mapq", type=int, default=20)
    parser.add_argument("--pileup_max_depth", type=int, default=100000)

    parser.add_argument("--strain_min_callable_bp", type=int, default=5000)
    parser.add_argument("--strain_min_callable_frac", type=float, default=0.8)
    parser.add_argument("--strain_min_target_sites", type=int, default=200)
    parser.add_argument("--strain_min_background_sites", type=int, default=500)
    parser.add_argument("--strain_min_total_mut_sites", type=int, default=0)

    parser.add_argument("--gene_min_callable_bp", type=int, default=500)
    parser.add_argument("--gene_min_callable_frac", type=float, default=0.5)
    parser.add_argument("--gene_min_target_sites", type=int, default=20)
    parser.add_argument("--gene_min_background_sites", type=int, default=50)
    parser.add_argument("--gene_min_total_mut_sites", type=int, default=0)

    parser.add_argument("--l1_min_callable_bp", type=int, default=500)
    parser.add_argument("--l1_min_callable_frac", type=float, default=0.5)
    parser.add_argument("--l1_min_target_sites", type=int, default=20)
    parser.add_argument("--l1_min_background_sites", type=int, default=50)
    parser.add_argument("--l1_min_total_mut_sites", type=int, default=0)
    args = parser.parse_args()

    args.patient_root = abs_path(args.patient_root)
    args.output = abs_path(args.output)
    args.coord_db = abs_path(args.coord_db)
    args.coord_ref_fasta = abs_path(args.coord_ref_fasta)
    if args.allele_out:
        args.allele_out = abs_path(args.allele_out)
    if args.allele_multi_summary_out:
        args.allele_multi_summary_out = abs_path(args.allele_multi_summary_out)

    if not os.path.isdir(args.patient_root):
        raise SystemExit(f"patient_root not found: {args.patient_root}")
    if not os.path.isfile(args.coord_db):
        raise SystemExit(f"coord_db not found: {args.coord_db}")
    if not os.path.isfile(args.coord_ref_fasta):
        raise SystemExit(f"coord_ref_fasta not found: {args.coord_ref_fasta}")

    all_coords = load_coordinates(args.coord_db)
    coord_ref_idx = load_coord_ref_fasta(args.coord_ref_fasta)
    run_utc = datetime.now(timezone.utc).isoformat()
    run_config = build_run_config(args, run_utc)

    rows = []
    allele_rows = []
    skipped = []
    strain_folders = sorted(path for path in glob(os.path.join(args.patient_root, "*_*")) if os.path.isdir(path))

    print(f"[INFO] patient_id={args.patient_id}")
    print(f"[INFO] patient_root={args.patient_root}")
    print(f"[INFO] found strain-like folders={len(strain_folders)}")

    for folder in strain_folders:
        if os.path.basename(folder).endswith("_combined_ref"):
            continue
        print(f"[INFO] analyzing {os.path.basename(folder)}")
        try:
            row, skip, allele_rows_strain = analyze_strain(folder, str(args.patient_id), all_coords, coord_ref_idx, run_config, args)
            if row is not None:
                rows.append(row)
                if allele_rows_strain:
                    allele_rows.extend(allele_rows_strain)
            elif skip is not None:
                skipped.append(skip)
        except Exception as exc:
            skipped.append({"Folder": os.path.basename(folder), "Reason": "exception", "Detail": str(exc)})
            print(f"[WARN] failed {os.path.basename(folder)}: {exc}")
            continue

    if not rows:
        skip_path = os.path.join(args.patient_root, f"analysis_skipped_{args.patient_id}.csv")
        if skipped:
            pd.DataFrame(skipped).to_csv(skip_path, index=False)
            print(f"[WARN] wrote skipped list: {skip_path}")
        raise SystemExit("No analyzable strains found for this patient.")

    df = pd.DataFrame(rows)
    df = apply_fdr(df)

    ordered = ordered_columns()
    for col in ordered:
        if col not in df.columns:
            df[col] = None
    extras = [c for c in df.columns if c not in ordered]
    df = df[ordered + extras]

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    df.to_csv(args.output, index=False)
    print(f"[INFO] saved merged report: {args.output}")

    if int(args.write_allele_tables) == 1:
        base_stem = os.path.splitext(args.output)[0]
        allele_out = args.allele_out if args.allele_out else f"{base_stem}.alleles.csv"
        allele_summary_out = args.allele_multi_summary_out if args.allele_multi_summary_out else f"{base_stem}.multi_allelic_summary.csv"
        allele_df = pd.DataFrame(allele_rows)
        if not allele_df.empty:
            ordered_allele_cols = [
                "PatientID",
                "Sample",
                "Type",
                "Region",
                "POS",
                "REF",
                "ALT",
                "DP",
                "AF",
                "MAF",
                "MAF_Bin",
                "IsMultiAllelicSite",
                "AltReads",
                "AltReadsEstimated",
                "AltReadsSource",
                "Context",
                "IsAPOBECTargetContext",
                "IsAPOBECChange",
                "IsAPOBEC",
            ]
            for col in ordered_allele_cols:
                if col not in allele_df.columns:
                    allele_df[col] = None
            extra_cols = [c for c in allele_df.columns if c not in ordered_allele_cols]
            allele_df = allele_df[ordered_allele_cols + extra_cols]
            allele_df.to_csv(allele_out, index=False)
        else:
            pd.DataFrame(columns=[
                "PatientID",
                "Sample",
                "Type",
                "Region",
                "POS",
                "REF",
                "ALT",
                "DP",
                "AF",
                "MAF",
                "MAF_Bin",
                "IsMultiAllelicSite",
                "AltReads",
                "AltReadsEstimated",
                "AltReadsSource",
                "Context",
                "IsAPOBECTargetContext",
                "IsAPOBECChange",
                "IsAPOBEC",
            ]).to_csv(allele_out, index=False)
        summary_rows = summarize_multi_allelic(allele_rows)
        summary_df = pd.DataFrame(summary_rows)
        if summary_df.empty:
            summary_df = pd.DataFrame(
                columns=[
                    "PatientID",
                    "Sample",
                    "Type",
                    "Region",
                    "MultiAltSites",
                    "MultiAltSites_WithAPOBECAlt",
                    "MultiAltAlleles",
                    "MultiAltAlleles_APOBEC",
                    "APOBEC_AF_Fraction_MultiAllelic",
                    "APOBEC_Read_Fraction_MultiAllelic",
                    "APOBEC_AF_Fraction_MultiAllelic_Bin1",
                    "APOBEC_AF_Fraction_MultiAllelic_Bin2",
                    "APOBEC_Read_Fraction_MultiAllelic_Bin1",
                    "APOBEC_Read_Fraction_MultiAllelic_Bin2",
                ]
            )
        summary_df.to_csv(allele_summary_out, index=False)
        print(f"[INFO] saved allele table: {allele_out}")
        print(f"[INFO] saved multi-allelic summary: {allele_summary_out}")

    if skipped:
        skip_path = os.path.join(args.patient_root, f"analysis_skipped_{args.patient_id}.csv")
        pd.DataFrame(skipped).to_csv(skip_path, index=False)
        print(f"[INFO] saved skipped records: {skip_path}")


if __name__ == "__main__":
    main()
