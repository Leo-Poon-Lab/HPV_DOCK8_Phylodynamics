#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(forcats)
  library(ggplot2)
  library(scales)
  library(patchwork)
})

base_dir <- "/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo"
st1_file <- file.path(base_dir, "analysis/competitive_mapping/gene_level_coverage_all_metrics.csv")
st2_dir <- file.path(base_dir, "temp/re-mapping_results")
meta_file <- file.path(base_dir, "data/user_samples_meta_refined.csv")
out_dir <- file.path(base_dir, "temp/re-mapping_results/patient_three_stage_visuals")
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

# Stage 1 thresholds are tuned to keep broad candidate sensitivity while removing
# ultra-low-support mappings from the competitive mapping matrix.
STAGE1_MIN_DEPTH <- 10
STAGE1_MIN_COV15 <- 10

WG_MIN_CALLABLE_BP <- 5000
WG_MIN_CALLABLE_FRAC <- 0.8
L1_MIN_CALLABLE_BP <- 500
L1_MIN_CALLABLE_FRAC <- 0.5

to_bool <- function(x) {
  if (is.logical(x)) return(x)
  xc <- tolower(as.character(x))
  ifelse(xc %in% c("true", "t", "1"), TRUE,
         ifelse(xc %in% c("false", "f", "0"), FALSE, NA))
}

parse_mdyy <- function(x) {
  p <- str_split_fixed(x, "\\.", 3)
  mm <- suppressWarnings(as.integer(p[, 1]))
  dd <- suppressWarnings(as.integer(p[, 2]))
  yy <- suppressWarnings(as.integer(p[, 3]))
  yyyy <- ifelse(yy >= 90, 1900 + yy, 2000 + yy)
  as.Date(sprintf("%04d-%02d-%02d", yyyy, mm, dd))
}

sample_short <- function(x) {
  paste0("M", str_remove(toupper(x), "^MET"))
}

theme_set(
  theme_minimal(base_size = 11) +
    theme(
      panel.grid.minor = element_blank(),
      plot.title = element_text(face = "bold", size = 13),
      plot.subtitle = element_text(size = 10),
      legend.title = element_text(face = "bold"),
      axis.title = element_text(face = "bold")
    )
)

# ---------- Load data ----------
meta <- read_csv(meta_file, show_col_types = FALSE) %>%
  transmute(
    Sample = toupper(SampleID),
    PatientID = as.numeric(PatientID),
    date = parse_mdyy(Collection_Date),
    SiteCode = SiteCode,
    SiteDetail = SiteDetail,
    Habitat = Habitat
  )

st1_raw <- read_csv(st1_file, show_col_types = FALSE) %>%
  transmute(
    Sample = toupper(SampleID),
    Type = Virus,
    Length = as.numeric(Length),
    Mean_Depth = as.numeric(Mean_Depth),
    Cov15 = as.numeric(Cov_Pct_15x)
  )

st1 <- st1_raw %>%
  group_by(Sample, Type) %>%
  summarise(
    st1_depth = weighted.mean(Mean_Depth, pmax(Length, 1), na.rm = TRUE),
    st1_cov15 = weighted.mean(Cov15, pmax(Length, 1), na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(stage1_pass = st1_depth >= STAGE1_MIN_DEPTH & st1_cov15 >= STAGE1_MIN_COV15)

st2_files <- list.files(st2_dir, pattern = "^final_report_[0-9]{4}\\.csv$", full.names = TRUE)
st3_files <- list.files(st2_dir, pattern = "^final_report_[0-9]{4}_L1\\.csv$", full.names = TRUE)
if (length(st2_files) == 0 || length(st3_files) == 0) {
  stop("Missing final_report stage files.")
}

st2 <- bind_rows(lapply(st2_files, read_csv, show_col_types = FALSE)) %>%
  transmute(
    Sample = toupper(Sample),
    PatientID_st2 = as.numeric(PatientID),
    Type = Type,
    wg_snvs = as.numeric(WG_SNVs),
    wg_callable_bp = as.numeric(WG_Callable_bp),
    wg_callable_frac = as.numeric(WG_Callable_frac),
    wg_low_power = to_bool(LOW_POWER),
    wg_apobec = as.numeric(WG_APOBEC_Enrichment)
  )

st3 <- bind_rows(lapply(st3_files, read_csv, show_col_types = FALSE)) %>%
  transmute(
    Sample = toupper(Sample),
    Type = Type,
    l1_snvs = as.numeric(L1_SNVs),
    l1_callable_bp = as.numeric(L1_Callable_bp),
    l1_callable_frac = as.numeric(L1_Callable_frac),
    l1_low_power = to_bool(L1_LOW_POWER)
  )

all_samples <- sort(unique(st2$Sample))

# Pair-level master table across three stages
pairs <- full_join(st1, st2, by = c("Sample", "Type")) %>%
  left_join(st3, by = c("Sample", "Type")) %>%
  filter(Sample %in% all_samples) %>%
  left_join(meta, by = "Sample") %>%
  mutate(
    PatientID = coalesce(PatientID_st2, PatientID),
    stage1_pass = replace_na(stage1_pass, FALSE),
    stage2_pass = replace_na(wg_snvs, 0) > 0,
    wg_power = (!replace_na(wg_low_power, TRUE)) &
      replace_na(wg_callable_bp, 0) >= WG_MIN_CALLABLE_BP &
      replace_na(wg_callable_frac, 0) >= WG_MIN_CALLABLE_FRAC,
    l1_power = (!replace_na(l1_low_power, TRUE)) &
      replace_na(l1_callable_bp, 0) >= L1_MIN_CALLABLE_BP &
      replace_na(l1_callable_frac, 0) >= L1_MIN_CALLABLE_FRAC,
    stage3_pass = stage2_pass & wg_power & l1_power,
    loss_s1_s2 = stage1_pass & !stage2_pass,
    loss_s2_s3_wg = stage2_pass & !wg_power,
    loss_s2_s3_l1 = stage2_pass & wg_power & !l1_power
  )

patient_ids <- sort(unique(pairs$PatientID))
patient_summaries <- list()
two_visit_summaries <- list()

for (pid in patient_ids) {
  d <- pairs %>% filter(PatientID == pid)
  if (nrow(d) == 0) next

  sample_tbl <- d %>%
    group_by(PatientID, Sample, date, SiteCode, SiteDetail, Habitat) %>%
    summarise(
      s1_count = sum(stage1_pass, na.rm = TRUE),
      s2_count = sum(stage2_pass, na.rm = TRUE),
      s3_count = sum(stage3_pass, na.rm = TRUE),
      s3_snvs = sum(ifelse(stage3_pass, wg_snvs, 0), na.rm = TRUE),
      mean_apobec_s3 = weighted.mean(ifelse(stage3_pass, wg_apobec, NA_real_), pmax(ifelse(stage3_pass, wg_snvs, 0), 1), na.rm = TRUE),
      lost_s1_s2 = sum(loss_s1_s2, na.rm = TRUE),
      lost_s2_s3_wg = sum(loss_s2_s3_wg, na.rm = TRUE),
      lost_s2_s3_l1 = sum(loss_s2_s3_l1, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(
      sample_id = sample_short(Sample),
      mean_apobec_s3 = ifelse(is.finite(mean_apobec_s3), mean_apobec_s3, NA_real_)
    ) %>%
    arrange(date, SiteCode, Sample)

  sample_levels <- sample_tbl$Sample
  if (length(sample_levels) == 0) next

  sample_lbl <- setNames(paste0(sample_tbl$SiteCode, "\n", sample_tbl$sample_id), sample_tbl$Sample)
  n_dates <- n_distinct(sample_tbl$date)

  # -------- Panel A: stage matrix --------
  panelA_df <- sample_tbl %>%
    select(Sample, date, s1_count, s2_count, s3_count) %>%
    pivot_longer(cols = c(s1_count, s2_count, s3_count), names_to = "Stage", values_to = "TypeCount") %>%
    mutate(
      Stage = recode(Stage,
                     s1_count = "S1 Competitive mapping",
                     s2_count = "S2 WG re-mapping",
                     s3_count = "S3 High-confidence retained"),
      Stage = factor(Stage, levels = c("S3 High-confidence retained", "S2 WG re-mapping", "S1 Competitive mapping")),
      Sample = factor(Sample, levels = sample_levels),
      date = as.factor(date)
    )

  pA <- ggplot(panelA_df, aes(x = Sample, y = Stage, fill = TypeCount)) +
    geom_tile(color = "white", linewidth = 0.25) +
    geom_text(aes(label = TypeCount), size = 2.8, color = "black") +
    facet_grid(. ~ date, scales = "free_x", space = "free_x") +
    scale_fill_gradientn(colors = c("#F1F5F9", "#93C5FD", "#2563EB", "#0F172A")) +
    scale_x_discrete(labels = sample_lbl) +
    labs(
      title = paste0("Patient ", pid, " | Three-stage type retention map"),
      subtitle = "Tile number = count of HPV types retained at each stage per sample",
      x = "Site and sample",
      y = NULL,
      fill = "Type count"
    ) +
    theme(
      axis.text.x = element_text(size = 7),
      strip.text = element_text(face = "bold", size = 9)
    )

  # -------- Panel B: sample-wise stage funnel --------
  panelB_df <- sample_tbl %>%
    select(Sample, SiteCode, date, s1_count, s2_count, s3_count) %>%
    pivot_longer(cols = c(s1_count, s2_count, s3_count), names_to = "Stage", values_to = "TypeCount") %>%
    mutate(
      Stage = recode(Stage,
                     s1_count = "S1",
                     s2_count = "S2",
                     s3_count = "S3"),
      Stage = factor(Stage, levels = c("S1", "S2", "S3")),
      date = as.factor(date)
    )

  median_line <- panelB_df %>%
    group_by(Stage) %>%
    summarise(TypeCount = median(TypeCount, na.rm = TRUE), .groups = "drop")

  pB <- ggplot(panelB_df, aes(x = Stage, y = TypeCount, group = Sample, color = SiteCode)) +
    geom_line(alpha = 0.65, linewidth = 0.7) +
    geom_point(aes(shape = date), size = 2.2, alpha = 0.9) +
    geom_line(data = median_line, aes(x = Stage, y = TypeCount, group = 1), inherit.aes = FALSE, color = "black", linewidth = 1.1) +
    geom_point(data = median_line, inherit.aes = FALSE, aes(x = Stage, y = TypeCount), color = "black", size = 2.8) +
    labs(
      title = "Stage funnel trajectories (each line = one sample)",
      subtitle = "Black line = patient median trajectory",
      x = "Mapping stage",
      y = "Retained HPV type count",
      color = "Site",
      shape = "Date"
    )

  # -------- Panel C: where attrition happens --------
  panelC_df <- sample_tbl %>%
    group_by(SiteCode) %>%
    summarise(
      loss_s1_s2 = sum(lost_s1_s2, na.rm = TRUE),
      loss_s2_s3_wg = sum(lost_s2_s3_wg, na.rm = TRUE),
      loss_s2_s3_l1 = sum(lost_s2_s3_l1, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    pivot_longer(
      cols = c(loss_s1_s2, loss_s2_s3_wg, loss_s2_s3_l1),
      names_to = "LossStage",
      values_to = "LostTypes"
    ) %>%
    mutate(
      LossStage = recode(LossStage,
                         loss_s1_s2 = "Lost from S1->S2",
                         loss_s2_s3_wg = "Lost by WG power",
                         loss_s2_s3_l1 = "Lost by L1 power"),
      SiteCode = fct_reorder(SiteCode, LostTypes, .fun = sum, .desc = TRUE)
    )

  pC <- ggplot(panelC_df, aes(x = SiteCode, y = LostTypes, fill = LossStage)) +
    geom_col(width = 0.72) +
    scale_fill_manual(values = c(
      "Lost from S1->S2" = "#9CA3AF",
      "Lost by WG power" = "#F59E0B",
      "Lost by L1 power" = "#DC2626"
    )) +
    labs(
      title = "Attrition decomposition by site",
      subtitle = "Which stage removes most types at each body site",
      x = "Site",
      y = "Lost type count",
      fill = NULL
    ) +
    theme(axis.text.x = element_text(angle = 20, hjust = 1))

  dashboard <- (pA / (pB | pC)) + plot_layout(heights = c(1.05, 1))
  dashboard_file <- file.path(out_dir, paste0("patient_", pid, "_stage_dashboard.png"))
  ggsave(dashboard_file, dashboard, width = 15, height = 11, dpi = 320)

  # ---------- Optional T1 vs T2 figure ----------
  if (n_dates == 2) {
    d_ord <- sort(unique(sample_tbl$date))
    t1 <- d_ord[1]
    t2 <- d_ord[2]

    site_t <- sample_tbl %>%
      group_by(date, SiteCode) %>%
      summarise(s3_count = sum(s3_count), .groups = "drop") %>%
      mutate(tp = ifelse(date == t1, "T1", "T2")) %>%
      pivot_wider(names_from = tp, values_from = s3_count, values_fill = 0) %>%
      mutate(delta = T2 - T1)

    pD1 <- ggplot(site_t, aes(y = fct_reorder(SiteCode, delta))) +
      geom_segment(aes(x = T1, xend = T2, yend = SiteCode), color = "#94A3B8", linewidth = 1.3) +
      geom_point(aes(x = T1), shape = 21, fill = "#E2E8F0", color = "#334155", size = 3.2, stroke = 0.5) +
      geom_point(aes(x = T2, fill = delta), shape = 21, color = "white", size = 4.0, stroke = 0.5) +
      scale_fill_gradient2(low = "#B91C1C", mid = "#64748B", high = "#047857", midpoint = 0) +
      labs(
        title = "Stage3 site burden change",
        subtitle = paste0("T1=", format(t1, "%Y-%m-%d"), " | T2=", format(t2, "%Y-%m-%d")),
        x = "Retained type count at S3",
        y = "Site",
        fill = "T2-T1"
      )

    type_t <- d %>%
      filter(stage3_pass) %>%
      group_by(date, Type) %>%
      summarise(snvs = sum(wg_snvs, na.rm = TRUE), .groups = "drop") %>%
      mutate(tp = ifelse(date == t1, "T1", "T2")) %>%
      pivot_wider(names_from = tp, values_from = snvs, values_fill = 0) %>%
      mutate(
        delta = T2 - T1,
        status = case_when(
          T1 == 0 & T2 > 0 ~ "Gained in T2",
          T1 > 0 & T2 == 0 ~ "Lost in T2",
          TRUE ~ "Shared"
        )
      ) %>%
      arrange(desc(abs(delta))) %>%
      slice_head(n = 20)

    pD2 <- ggplot(type_t, aes(x = delta, y = fct_reorder(Type, delta), fill = status)) +
      geom_col(width = 0.72) +
      geom_vline(xintercept = 0, color = "black", linewidth = 0.45) +
      scale_fill_manual(values = c(
        "Gained in T2" = "#059669",
        "Lost in T2" = "#DC2626",
        "Shared" = "#64748B"
      )) +
      labs(
        title = "Top type turnover (Stage3 only)",
        subtitle = "Delta SNVs = T2 - T1",
        x = "Delta SNVs",
        y = "HPV type",
        fill = NULL
      )

    pD <- pD1 | pD2
    pD <- pD + plot_annotation(title = paste0("Patient ", pid, " | Longitudinal delta focus"))
    delta_file <- file.path(out_dir, paste0("patient_", pid, "_T1T2_delta.png"))
    ggsave(delta_file, pD, width = 15, height = 6.5, dpi = 320)

    two_visit_summaries[[as.character(pid)]] <- tibble(
      PatientID = pid,
      date_T1 = t1,
      date_T2 = t2,
      days_between = as.integer(t2 - t1),
      top_gain_site = site_t$SiteCode[which.max(site_t$delta)][1],
      top_gain_site_delta = max(site_t$delta, na.rm = TRUE),
      top_loss_site = site_t$SiteCode[which.min(site_t$delta)][1],
      top_loss_site_delta = min(site_t$delta, na.rm = TRUE),
      gained_types = sum(type_t$status == "Gained in T2"),
      lost_types = sum(type_t$status == "Lost in T2"),
      shared_types = sum(type_t$status == "Shared")
    )
  }

  site_rank <- sample_tbl %>%
    group_by(SiteCode) %>%
    summarise(
      total_s3 = sum(s3_count, na.rm = TRUE),
      retention_23 = mean(s3_count / pmax(s2_count, 1), na.rm = TRUE),
      .groups = "drop"
    ) %>%
    arrange(desc(total_s3))

  patient_summaries[[as.character(pid)]] <- tibble(
    PatientID = pid,
    n_samples = n_distinct(sample_tbl$Sample),
    n_dates = n_distinct(sample_tbl$date),
    start_date = min(sample_tbl$date, na.rm = TRUE),
    end_date = max(sample_tbl$date, na.rm = TRUE),
    total_s1 = sum(sample_tbl$s1_count, na.rm = TRUE),
    total_s2 = sum(sample_tbl$s2_count, na.rm = TRUE),
    total_s3 = sum(sample_tbl$s3_count, na.rm = TRUE),
    median_retention_12 = median(sample_tbl$s2_count / pmax(sample_tbl$s1_count, 1), na.rm = TRUE),
    median_retention_23 = median(sample_tbl$s3_count / pmax(sample_tbl$s2_count, 1), na.rm = TRUE),
    top_site_s3 = site_rank$SiteCode[1],
    top_site_s3_count = site_rank$total_s3[1],
    dashboard_file = dashboard_file
  )
}

summary_tbl <- bind_rows(patient_summaries) %>% arrange(PatientID)
write_csv(summary_tbl, file.path(out_dir, "patient_stage_summary.csv"))

if (length(two_visit_summaries) > 0) {
  two_tbl <- bind_rows(two_visit_summaries) %>% arrange(PatientID)
  write_csv(two_tbl, file.path(out_dir, "patient_two_visit_deltas.csv"))
}

readme <- c(
  "Patient three-stage visualization set",
  paste0("Generated at: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "",
  "Stage definitions:",
  paste0("- S1 Competitive mapping pass: weighted Mean_Depth >= ", STAGE1_MIN_DEPTH,
         " and weighted Cov_Pct_15x >= ", STAGE1_MIN_COV15),
  "- S2 WG re-mapping pass: WG_SNVs > 0",
  paste0("- S3 High-confidence retained: S2 pass and WG power pass (callable_bp>=", WG_MIN_CALLABLE_BP,
         ", callable_frac>=", WG_MIN_CALLABLE_FRAC,
         ") and L1 power pass (callable_bp>=", L1_MIN_CALLABLE_BP,
         ", callable_frac>=", L1_MIN_CALLABLE_FRAC, ")"),
  "",
  "Outputs:",
  "- patient_<ID>_stage_dashboard.png",
  "- patient_<ID>_T1T2_delta.png (only for patients with 2 dates)",
  "- patient_stage_summary.csv",
  "- patient_two_visit_deltas.csv"
)
writeLines(readme, file.path(out_dir, "README_three_stage_visuals.txt"))

cat("Done. Files saved in:", out_dir, "\n")
