import sys
import csv
import subprocess
import os

# --- L1-Centric Selection Criteria ---
MIN_L1_BREADTH = 95.0  # Percentage
MIN_L1_DEPTH = 5.0    # x

# --- Slicing QC Constants ---
MIN_L1_PIDENT = 90.0
MIN_L1_ALN_LEN = 1000  # fallback absolute min
MIN_L1_ALN_RATIO = 80.0 # Percentage (Alignment / Query Length)

def parse_coords_db(coord_db_path):
    """
    Parses the coordinate CSV into a dict: {TypeID: (start, end)}
    Format in CSV: L1_Start, L1_End
    """
    coords = {}
    try:
        with open(coord_db_path, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                virus = row.get('Virus', '').strip()
                start = row.get('L1_Start', '').strip()
                end = row.get('L1_End', '').strip()
                if virus and start and end:
                    try:
                        coords[virus] = (int(start), int(end))
                    except ValueError:
                        pass
    except Exception as e:
        sys.stderr.write(f"Error reading coords DB: {e}\n")
    return coords

def get_samtools_coverage(bam_file, region):
    """
    Runs samtools coverage -r region and returns (breadth, meandepth).
    Key Fix: Added -q 20 -Q 20 to ignore low MAPQ/BaseQ reads (Cross-Mapping Defense).
    """
    try:
        # samtools coverage output columns:
        # #rname startptr endptr numreads covbases coverage meandepth meanbaseq meanmapq
        cmd = ["/usr/bin/samtools", "coverage", "-q", "20", "-Q", "20", "-r", region, bam_file]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            return 0.0, 0.0
        
        lines = result.stdout.strip().split('\n')
        if len(lines) < 2: # Header only or empty
            return 0.0, 0.0
            
        # Parse data line (2nd line)
        parts = lines[1].split('\t')
        breadth = float(parts[5]) # coverage column (percentage)
        depth = float(parts[6])   # meandepth column
        return breadth, depth
    except Exception as e:
        return 0.0, 0.0

def find_dominant(bam_file, coord_db_path):
    """
    Scans the BAM file for all references with reads, then checks L1 coverage for each.
    Returns a list of dominant types.
    """
    dominant_types = []
    
    # 1. Get all chromosomes with reads (Quick check)
    try:
        cmd = ["/usr/bin/samtools", "idxstats", bam_file]
        res = subprocess.run(cmd, capture_output=True, text=True)
        if res.returncode != 0: return []
        
        candidates = []
        for line in res.stdout.strip().split('\n'):
            parts = line.split('\t')
            if len(parts) >= 3 and int(parts[2]) > 0: # mapped reads > 0
                candidates.append(parts[0])
    except:
        return []

    # 2. Check L1 Criteria for each candidate
    coord_db = parse_coords_db(coord_db_path)
    
    for hpv_type in candidates:
        if hpv_type not in coord_db: continue
        
        start, end = coord_db[hpv_type]
        region = f"{hpv_type}:{start}-{end}"
        
        cov, dep = get_samtools_coverage(bam_file, region)
        
        # Check Criteria
        status = "FAIL"
        if cov >= MIN_L1_BREADTH and dep >= MIN_L1_DEPTH:
            status = "PASS"
            dominant_types.append(hpv_type)
            
        # Log to stderr for main script to catch in log file
        sys.stderr.write(f"[CHECK] {hpv_type} L1({start}-{end}): Cov={cov}%, Depth={dep}x -> {status}\n")
            
    return dominant_types

def get_coords(coord_db_path, type_id):
    coord_db = parse_coords_db(coord_db_path)
    if type_id in coord_db:
        s, e = coord_db[type_id]
        return f"{s}-{e}"
    return ""

def parse_blast_and_slice(blast_out, consensus_fa, output_fasta, sample_id, type_id):
    """
    Extracts L1 from consensus based on BLAST result.
    Logic: Find best hit, extract coordinates, handle reverse complement.
    Inputs: blast_out (fmt 6 std qlen: 13 cols)
    """
    try:
        if not os.path.exists(blast_out) or os.path.getsize(blast_out) == 0:
            return "No Blast Hit"
            
        with open(blast_out, 'r') as f:
            line = f.readline()
            if not line: return "Empty Blast"
            # Blast fmt 6 std: qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore
            # + qlen (13th column)
            cols = line.strip().split('\t')
            
            pident = float(cols[2])
            aln_len = int(cols[3])
            
            # QC Check 1: Identity
            if pident < MIN_L1_PIDENT:
                return f"Low Identity ({pident}%)"
            
            # QC Check 2: Length Ratio (If qlen available)
            ratio_msg = ""
            if len(cols) >= 13:
                qlen = int(cols[12])
                if qlen > 0:
                    ratio = (aln_len / qlen) * 100
                    ratio_msg = f"Ratio={ratio:.1f}%"
                    
                    if ratio < MIN_L1_ALN_RATIO:
                        return f"Incomplete Alignment ({ratio:.1f}%)"
            
            # QC Check 3: Absolute Length
            if aln_len < MIN_L1_ALN_LEN:
                 return f"Short Alignment ({aln_len}bp)"

            # q=L1(query), s=Consensus(subject)
            s_start = int(cols[8])
            s_end = int(cols[9])
            
        # Read Consensus Sequence
        seq_dict = {}
        header = ""
        seq = ""
        with open(consensus_fa, 'r') as f:
            for l in f:
                if l.startswith('>'):
                    header = l.strip()
                else:
                    seq += l.strip()
                    
        # Extract Slice (1-based coords from BLAST)
        # Python is 0-based
        start_idx, end_idx = 0, 0
        is_rev = False
        
        if s_start <= s_end:
            # Forward: s_start -> s_end
            start_idx = s_start - 1
            end_idx = s_end
            if start_idx < 0: start_idx = 0
            if end_idx > len(seq): end_idx = len(seq)
            extracted_seq = seq[start_idx:end_idx]
        else:
            # Reverse: s_end -> s_start (on plus strand coords), then RC
            is_rev = True
            start_idx = s_end - 1
            end_idx = s_start
            if start_idx < 0: start_idx = 0
            if end_idx > len(seq): end_idx = len(seq)
            raw_slice = seq[start_idx:end_idx]
            
            # RevComp
            comp_map = str.maketrans("ACGTMRWSYKVHDBNacgtmrwsykvhdbn", "TGCAKYWSRMBDHVNtgcakywsrmbdhvn")
            extracted_seq = raw_slice.translate(comp_map)[::-1]

        # Write Output
        header = f">{sample_id}_{type_id}_L1"
        with open(output_fasta, 'w') as f:
            f.write(f"{header}\n{extracted_seq}\n")
            
        return f"Success (Len={aln_len}, Id={pident}%, {ratio_msg})"

    except Exception as e:
        return str(e)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(1)
        
    action = sys.argv[1]
    
    if action == "find_dominant":
        # Usage: python helper.py find_dominant bam_file coord_db
        bam_file = sys.argv[2]
        coord_db = sys.argv[3]
        types = find_dominant(bam_file, coord_db)
        if types: print(" ".join(types))
        
    elif action == "get_coords":
        # Usage: python helper.py get_coords coord_db type_id
        db_file = sys.argv[2]
        type_id = sys.argv[3]
        res = get_coords(db_file, type_id)
        if res: print(res) 
        
    elif action == "slice_l1":
        # Usage: python helper.py slice_l1 blast_out cons_fa out_fa sample type
        res = parse_blast_and_slice(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6])
        print(res)
