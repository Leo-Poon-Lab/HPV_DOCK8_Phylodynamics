#!/usr/bin/env python3
"""
Repair known metadata issues in temp/re-mapping_results outputs:
1) PatientID / RunConfigJSON.patient_id incorrectly fixed to 6000.
2) skipped.csv polluted by *_combined_ref intermediate folders.

Edits files in-place with a .bak backup next to each file.
Uses only Python stdlib (csv/json/re) so it can run on server and local.
"""

from __future__ import annotations

import csv
import json
import os
import re
import shutil
import sys
import tempfile
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Tuple


_REPORT_RE = re.compile(r"^final_report_(\d+)(?:_L1)?\.csv$")
_SKIPPED_RE = re.compile(r"^final_report_(\d+)(?:_L1)?\.skipped\.csv$")


@dataclass
class RepairStats:
    path: str
    patient_id: str
    rows_in: int
    rows_out: int
    patientid_fixed_rows: int
    runconfig_fixed_rows: int
    removed_combined_ref_rows: int


def _infer_patient_id_from_filename(path: str) -> Optional[str]:
    base = os.path.basename(path)
    m = _REPORT_RE.match(base) or _SKIPPED_RE.match(base)
    return m.group(1) if m else None


def _is_combined_ref_row(row: Dict[str, str]) -> bool:
    folder = (row.get("Folder") or "").strip()
    path = (row.get("Path") or "").strip()
    if folder.endswith("_combined_ref"):
        return True
    if "_combined_ref" in folder:
        return True
    if path.endswith("_combined_ref"):
        return True
    if "_combined_ref/" in path or "_combined_ref\\" in path:
        return True
    return False


def _repair_runconfig_json(raw: str, patient_id: str) -> Tuple[str, bool]:
    if raw is None:
        return raw, False
    raw = raw.strip()
    if not raw:
        return raw, False
    try:
        obj = json.loads(raw)
    except Exception:
        return raw, False
    if not isinstance(obj, dict):
        return raw, False
    changed = False
    if obj.get("patient_id") != patient_id:
        obj["patient_id"] = patient_id
        changed = True
    # Keep patient_root as-is; it is already informative and patient-specific.
    if not changed:
        return raw, False
    return json.dumps(obj, separators=(",", ":"), sort_keys=True), True


def _write_csv_atomic(dst_path: str, fieldnames: List[str], rows: Iterable[Dict[str, str]]) -> None:
    dst_dir = os.path.dirname(os.path.abspath(dst_path)) or "."
    fd, tmp_path = tempfile.mkstemp(prefix=".tmp_", suffix=".csv", dir=dst_dir)
    os.close(fd)
    try:
        with open(tmp_path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
            w.writeheader()
            for r in rows:
                w.writerow(r)
        os.replace(tmp_path, dst_path)
    finally:
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass


def repair_file(path: str) -> Optional[RepairStats]:
    patient_id = _infer_patient_id_from_filename(path)
    if not patient_id:
        return None

    is_skipped = path.endswith(".skipped.csv")
    with open(path, newline="") as f:
        r = csv.DictReader(f)
        if not r.fieldnames:
            return None
        fieldnames = list(r.fieldnames)
        rows_in: List[Dict[str, str]] = list(r)

    patientid_fixed_rows = 0
    runconfig_fixed_rows = 0
    removed_combined_ref_rows = 0
    rows_out: List[Dict[str, str]] = []

    for row in rows_in:
        if is_skipped and _is_combined_ref_row(row):
            removed_combined_ref_rows += 1
            continue

        if "PatientID" in row and (row.get("PatientID") or "").strip() != patient_id:
            row["PatientID"] = patient_id
            patientid_fixed_rows += 1

        if "RunConfigJSON" in row:
            fixed, changed = _repair_runconfig_json(row.get("RunConfigJSON") or "", patient_id)
            if changed:
                row["RunConfigJSON"] = fixed
                runconfig_fixed_rows += 1

        rows_out.append(row)

    if patientid_fixed_rows == 0 and runconfig_fixed_rows == 0 and removed_combined_ref_rows == 0:
        return RepairStats(
            path=path,
            patient_id=patient_id,
            rows_in=len(rows_in),
            rows_out=len(rows_out),
            patientid_fixed_rows=0,
            runconfig_fixed_rows=0,
            removed_combined_ref_rows=0,
        )

    bak_path = path + ".bak"
    if not os.path.exists(bak_path):
        shutil.copy2(path, bak_path)

    _write_csv_atomic(path, fieldnames, rows_out)
    return RepairStats(
        path=path,
        patient_id=patient_id,
        rows_in=len(rows_in),
        rows_out=len(rows_out),
        patientid_fixed_rows=patientid_fixed_rows,
        runconfig_fixed_rows=runconfig_fixed_rows,
        removed_combined_ref_rows=removed_combined_ref_rows,
    )


def main(argv: List[str]) -> int:
    if len(argv) != 2:
        print(f"Usage: {argv[0]} <re-mapping_results_dir>", file=sys.stderr)
        return 2

    base_dir = os.path.abspath(argv[1])
    if not os.path.isdir(base_dir):
        print(f"[ERROR] Not a directory: {base_dir}", file=sys.stderr)
        return 2

    files = []
    for name in os.listdir(base_dir):
        if not name.startswith("final_report_"):
            continue
        if not (name.endswith(".csv") or name.endswith(".skipped.csv")):
            continue
        files.append(os.path.join(base_dir, name))
    files.sort()

    repaired: List[RepairStats] = []
    skipped = 0
    for p in files:
        st = repair_file(p)
        if st is None:
            skipped += 1
            continue
        repaired.append(st)

    total_fixed_patientid = sum(s.patientid_fixed_rows for s in repaired)
    total_fixed_runconfig = sum(s.runconfig_fixed_rows for s in repaired)
    total_removed_combined = sum(s.removed_combined_ref_rows for s in repaired)

    print(f"[OK] scanned_files={len(files)} repaired_files={len(repaired)} skipped_files={skipped}")
    print(f"[OK] patientid_fixed_rows={total_fixed_patientid} runconfig_fixed_rows={total_fixed_runconfig}")
    print(f"[OK] removed_combined_ref_rows={total_removed_combined}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))

