#!/bin/bash
set -euo pipefail

# ==============================================================================
# HPV Strain Reconstruction Pipeline - PATIENT CENTRIC (HARDENED V4 ULTIMATE)
# ==============================================================================
# 2026-02-06 Final Fixes:
# 1. Helper Script: Enforced -q 20 -Q 20, Ratio 80%, Identity 90%.
# 2. Consensus: Dedup (Fixmate+Markdup), Haploid, Tab-Masking.
# 3. Safety: pipefail enabled, syntax checked.
# ==============================================================================

# --- Configuration ---
BASE_DIR="/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction"
INPUT_META="${BASE_DIR}/inputs/user_samples_meta_refined.csv"
INPUT_BAMS_DIR="/home/ubuntu/HPV_evo/ref_assembly/mapping_results"

# READS (Repaired)
READS_DIR="/home/ubuntu/HPV_evo/kneaddata/merged/repaired"

REF_DB_PATH="/home/ubuntu/HPV_evo/ref_assembly/hpv_ref_combine.fasta"
COORD_DB="${BASE_DIR}/inputs/extract_gb_hpv_ref_combine.csv"
HELPER_SCRIPT="${BASE_DIR}/scripts/helper_reconstruct.py"

# Tools
PYTHON="/home/ubuntu/miniconda3/bin/python3"
BLASTN="/home/ubuntu/miniconda3/bin/blastn"
MAKEBLASTDB="/home/ubuntu/miniconda3/bin/makeblastdb"
BCFTOOLS="/home/ubuntu/tool/bcftools-1.20/bcftools"
SAMTOOLS="/usr/bin/samtools"
BOWTIE2="/usr/bin/bowtie2"

OUT_CONS="${BASE_DIR}/consensus_seqs"
OUT_BAMS="${BASE_DIR}/mapped_bams"
LOG_DIR="${BASE_DIR}/logs"

THREADS=12
MAX_JOBS=1

mkdir -p "${OUT_CONS}" "${OUT_BAMS}" "${LOG_DIR}"

process_sample() {
    local SAMPLE_ID="$1"
    local PATIENT_ID="$2"
    
    local P_CONS="${OUT_CONS}/${PATIENT_ID}"
    local P_BAMS="${OUT_BAMS}/${PATIENT_ID}"
    local LOG="${LOG_DIR}/${SAMPLE_ID}.log"
    
    mkdir -p "${P_CONS}" "${P_BAMS}"
    echo "Processing ${SAMPLE_ID} (Patient: ${PATIENT_ID})..." > "${LOG}"
    
    # 1. Locate Competitive BAM
    COMP_BAM="${INPUT_BAMS_DIR}/${SAMPLE_ID}_competitive.sorted.bam"
    if [ ! -f "${COMP_BAM}" ]; then
        UPPER_ID=$(echo "${SAMPLE_ID}" | tr '[:lower:]' '[:upper:]')
        COMP_BAM="${INPUT_BAMS_DIR}/${UPPER_ID}_competitive.sorted.bam"
        if [ ! -f "${COMP_BAM}" ]; then
            echo "Error: Competitive BAM not found for ${SAMPLE_ID}" >> "${LOG}"
            return
        fi
    fi
    
    # 2. Identify Dominant Types
    DOMINANT_TYPES=$(${PYTHON} "${HELPER_SCRIPT}" find_dominant "${COMP_BAM}" "${COORD_DB}")
    
    if [ -z "${DOMINANT_TYPES}" ]; then
        echo "No dominant types found." >> "${LOG}"
        return
    fi
    
    # 3. Reconstruct
    for TYPE in ${DOMINANT_TYPES}; do
        echo "  -> Reconstructing Type: ${TYPE}" >> "${LOG}"
        
        WORKDIR="${P_BAMS}/${SAMPLE_ID}_${TYPE}"
        mkdir -p "${WORKDIR}"
        
        # Extract Ref
        ${SAMTOOLS} faidx "${REF_DB_PATH}" "${TYPE}" > "${WORKDIR}/ref_original.fa"
        
        # Reads
        UPPER_ID=$(echo "${SAMPLE_ID}" | tr '[:lower:]' '[:upper:]')
        R1="${READS_DIR}/${UPPER_ID}_R1.fastq"
        R2="${READS_DIR}/${UPPER_ID}_R2.fastq"
        if [ ! -f "${R1}" ]; then
             R1="${READS_DIR}/${SAMPLE_ID}_R1.fastq"
             R2="${READS_DIR}/${SAMPLE_ID}_R2.fastq"
        fi
        
        if [ ! -f "${R1}" ]; then
             echo "    [ERROR] Reads not found: ${R1}" >> "${LOG}"
             continue
        fi
        
        # Round 1 Mapping & Dedup (V4 Ultimate)
        # 1. Map (Namesorted for fixmate) -> 2. Fixmate (-m) -> 3. Sort -> 4. Markdup (-r)
        # Fix: Use ${THREADS} for collate, ensure correct syntax: collate -@ <threads> -O -u -
        ${BOWTIE2}-build "${WORKDIR}/ref_original.fa" "${WORKDIR}/ref_idx" >/dev/null 2>&1
        ${BOWTIE2} -x "${WORKDIR}/ref_idx" -1 "${R1}" -2 "${R2}" \
                --local --no-unal -p "${THREADS}" 2>>"${LOG}" | \
        ${SAMTOOLS} view -bS - | \
        ${SAMTOOLS} collate -@ "${THREADS}" -O -u - | \
        ${SAMTOOLS} fixmate -m -u - - | \
        ${SAMTOOLS} sort -@ "${THREADS}" - | \
        ${SAMTOOLS} markdup - "${WORKDIR}/round1.dedup.bam" 2>>"${LOG}"
        
        ${SAMTOOLS} index "${WORKDIR}/round1.dedup.bam"
        
        # --- HARDENING STEP 1: Strict Call ---
        # -q 20 (MapQ), -Q 20 (BaseQ), --ploidy 1 (Haploid)
        # Input is now DEDUP BAM
        ${BCFTOOLS} mpileup -Ou -q 20 -Q 20 -f "${WORKDIR}/ref_original.fa" "${WORKDIR}/round1.dedup.bam" 2>>"${LOG}" | \
        ${BCFTOOLS} call -mv --ploidy 1 -Oz -o "${WORKDIR}/round1.vcf.gz" 2>>"${LOG}"
        ${BCFTOOLS} index "${WORKDIR}/round1.vcf.gz"
        
        # --- HARDENING STEP 2: Mask Low Coverage ---
        # Fix: Ensure TAB separation for BED
        ${SAMTOOLS} depth -a -q 20 -Q 20 "${WORKDIR}/round1.dedup.bam" | \
        awk -v OFS="\t" '$3 < 5 {print $1, $2-1, $2}' > "${WORKDIR}/mask.bed"
        
        # Check if masking needed
        if [ -s "${WORKDIR}/mask.bed" ]; then
             ${BCFTOOLS} consensus -f "${WORKDIR}/ref_original.fa" \
                --mask "${WORKDIR}/mask.bed" --mask-with N \
                "${WORKDIR}/round1.vcf.gz" > "${WORKDIR}/consensus_wg.fa"
        else
             ${BCFTOOLS} consensus -f "${WORKDIR}/ref_original.fa" \
                "${WORKDIR}/round1.vcf.gz" > "${WORKDIR}/consensus_wg.fa"
        fi
            
        # --- HARDENING STEP 3: Consensus QC ---
        SEQ_LEN=$(grep -v "^>" "${WORKDIR}/consensus_wg.fa" | tr -d '\n' | wc -c)
        N_COUNT=$(grep -v "^>" "${WORKDIR}/consensus_wg.fa" | tr -d '\n' | tr '[:lower:]' '[:upper:]' | tr -cd 'N' | wc -c)
        IUPAC_COUNT=$(grep -v "^>" "${WORKDIR}/consensus_wg.fa" | tr -d '\n' | tr '[:lower:]' '[:upper:]' | tr -d 'ACGTN' | wc -c)
        
        echo "    Consensus QC: Len=${SEQ_LEN} | N=${N_COUNT} | IUPAC=${IUPAC_COUNT}" >> "${LOG}"
        if [ "${IUPAC_COUNT}" -gt 0 ]; then
             echo "      [WARN] Haploid Violation? IUPAC codes detected!" >> "${LOG}"
        fi

        # Verify mask.bed size
        N_MASK_BASES=$(wc -l < "${WORKDIR}/mask.bed")
        echo "    Masked Low-Cov Bases: ${N_MASK_BASES}" >> "${LOG}"

        # --- SAVE WG CONSENSUS ---
        # For downstream re-mapping per patient
        cp "${WORKDIR}/consensus_wg.fa" "${P_CONS}/${SAMPLE_ID}_${TYPE}_WG.fasta"

        # Dynamic L1 Slicing
        COORDS=$(${PYTHON} "${HELPER_SCRIPT}" get_coords "${COORD_DB}" "${TYPE}")
        if [ -z "${COORDS}" ]; then continue; fi
        
        ${SAMTOOLS} faidx "${REF_DB_PATH}" "${TYPE}:${COORDS}" > "${WORKDIR}/query_l1.fa"
        # Fix: Add qlen to output for Ratio calculation
        ${MAKEBLASTDB} -in "${WORKDIR}/consensus_wg.fa" -dbtype nucl >/dev/null 2>&1
        ${BLASTN} -query "${WORKDIR}/query_l1.fa" -db "${WORKDIR}/consensus_wg.fa" \
                 -outfmt "6 std qlen" -max_target_seqs 1 -max_hsps 1 > "${WORKDIR}/blast.out"
        
        SLICE_STATUS=$(${PYTHON} "${HELPER_SCRIPT}" slice_l1 "${WORKDIR}/blast.out" "${WORKDIR}/consensus_wg.fa" "${P_CONS}/${SAMPLE_ID}_${TYPE}_L1.fasta" "${SAMPLE_ID}" "${TYPE}")
        echo "    Slice Status: ${SLICE_STATUS}" >> "${LOG}"
    done
    
    echo "Done with ${SAMPLE_ID}" >> "${LOG}"
}

echo "--- Starting Patient-Centric Reconstruction (HARDENED V4 ULTIMATE) ---"
tail -n +2 "${INPUT_META}" | awk -F, '{print $1, $2}' | sort -k2,2n -k1,1 | while read SAMPLE_ID PATIENT_ID; do
    if [ -z "${SAMPLE_ID}" ] || [ -z "${PATIENT_ID}" ]; then continue; fi
    process_sample "${SAMPLE_ID}" "${PATIENT_ID}"
done
echo "=== All Patients Finished at $(date) ==="
