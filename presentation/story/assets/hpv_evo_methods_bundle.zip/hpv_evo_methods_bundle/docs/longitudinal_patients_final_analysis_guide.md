# Longitudinal Patients: Final Figure Paths, Interpretation, and Meaning

This file supersedes the earlier recombination-only note. It summarizes the **full agreed analysis framework for the 7 longitudinal patients**, including:

- same-time spatial structure across sites
- persist vs site transfer vs introduction/loss across time
- all-site fixed-difference / iSNV evidence for persistent types
- exploratory recombination-candidate screening plots

The 7 longitudinal patients are:

- `6003`
- `6004`
- `6005`
- `6007`
- `6009`
- `6020`
- `6021`

## 1. Same-Time Spatial Structure Across Sites

### Main directory

`/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/patient_site_ringplots`

### Purpose

These ring plots are used to ask:

- within one patient at one timepoint, how much of the HPV population is shared across sites?
- which site pairs carry identical consensus?
- which site pairs carry near-identical consensus?
- where is there evidence of strong spatial structure instead of a freely mixed within-host pool?

### How to read the ring plots

- One figure = one `patient + date`
- Each sector = one site
- `n=...` beside the site label = strict type count at that site
- Sector fill intensity reflects the site-level type burden
- Blue chord = identical consensus across two sites
- Orange chord = similar consensus across two sites, with current threshold `<= 5 SNP`
- Missing / unsampled sites are left unfilled

### Meaning

- Many blue links suggest shared strains across skin sites and support within-host spatial spread or common reservoir structure
- Orange links suggest closely related but not strictly identical strains across sites
- Sparse links or only isolated clusters suggest strong site structure

### Important limitation

These ring plots are **same-time spatial structure figures**. They support the idea of site sharing and possible self-transfer ecology, but they do **not** by themselves prove directionality.

### Ring-plot paths for the 7 longitudinal patients

- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/patient_site_ringplots/Patient6003_2011-02-16_ring_linkage.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/patient_site_ringplots/Patient6003_2016-07-06_ring_linkage.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/patient_site_ringplots/Patient6004_2011-04-06_ring_linkage.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/patient_site_ringplots/Patient6004_2016-09-13_ring_linkage.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/patient_site_ringplots/Patient6005_2011-07-19_ring_linkage.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/patient_site_ringplots/Patient6005_2013-07-08_ring_linkage.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/patient_site_ringplots/Patient6007_2013-03-12_ring_linkage.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/patient_site_ringplots/Patient6007_2013-05-29_ring_linkage.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/patient_site_ringplots/Patient6009_2013-07-11_ring_linkage.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/patient_site_ringplots/Patient6009_2013-08-06_ring_linkage.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/patient_site_ringplots/Patient6020_2015-10-05_ring_linkage.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/patient_site_ringplots/Patient6020_2015-11-25_ring_linkage.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/patient_site_ringplots/Patient6021_2015-11-23_ring_linkage.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/patient_site_ringplots/Patient6021_2016-07-13_ring_linkage.png`

PDF versions with the same names also exist in the same directory.

## 2. Same-Time Cross-Site Consensus Story

### Main directory

`/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/site_consensus_story`

### Main figures

- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/site_consensus_story/patient_site_consensus_overview.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/site_consensus_story/patient_site_consensus_examples.png`

### Main tables

- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/site_consensus_story/patient_time_pair_summary.csv`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/site_consensus_story/patient_time_type_class_summary.csv`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/site_consensus_story/multisite_type_detail.csv`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/site_consensus_story/patient_site_consensus_representatives.csv`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/site_consensus_story/story_notes_zh.md`

### What these figures quantify

The overview figure summarizes same-time site-pair distances:

- `Exact`
- `1-5 SNP`
- `>5 SNP`

and multisite-type classes:

- `Shared consensus`
- `Near-identical`
- `Site-structured`
- `Strongly divergent`

### Main agreed interpretation

This layer answers:

- is a patient’s HPV population spatially homogeneous or site-structured at one timepoint?
- when a type appears at multiple sites, is it literally the same strain or a site-specific variant cluster?

This matters because:

- exact or near-exact same-time site sharing makes later cross-time transfer more biologically plausible
- strong same-time site structure warns that later cross-time changes may reflect reservoir complexity rather than simple de novo evolution

### Key agreed numbers from `story_notes_zh.md`

Across the 7 longitudinal patients:

- `224` multisite `patient-time-type` events were identified
- `98` were `Shared consensus`
- `43` were `Near-identical`
- therefore `141 / 224 = 62.9%` were nearly unchanged across sites
- `83 / 224 = 37.1%` showed strong site effect

## 3. Across-Time Type Fate: Persist, Transfer, Mutation-Like Change, Introduction, Loss

### Main directory

`/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4`

### Main patient overview figures

- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4/Patient6003_allsite_dynamics_overview_v4.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4/Patient6004_allsite_dynamics_overview_v4.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4/Patient6005_allsite_dynamics_overview_v4.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4/Patient6007_allsite_dynamics_overview_v4.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4/Patient6009_allsite_dynamics_overview_v4.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4/Patient6020_allsite_dynamics_overview_v4.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4/Patient6021_allsite_dynamics_overview_v4.png`

### Supporting tables

- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4/all_patients_overview_summary_v4.csv`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4/all_patients_type_fate_details_v4.csv`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4/all_patients_possible_mutation_evidence_v4.csv`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4/longitudinal_7patients_type_change_breakdown_v1.csv`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4/cohort_allsite_fate_stackedbar_v4.png`

### What each patient overview figure means

These overview figures are the main cross-time summary for each patient.

#### Top panel

The top bar plot partitions all types across both dates into:

- `Loss`
- `Introduction`
- `Possible mutation`
- `Site transfer`
- `Persist in place`

Operational interpretation in the current all-site framework:

- `Persist in place`: present at both dates and an exact consensus match is observed in-place
- `Site transfer`: present at both dates and an exact consensus match exists across dates, but the best match is at another site
- `Possible mutation`: present at both dates but no exact cross-time match; nearest T1/T2 consensus pair differs by fixed SNPs
- `Introduction`: absent at T1, present at T2
- `Loss`: present at T1, absent at T2

#### Bottom panel

The bottom panel only expands the `Possible mutation` group.

For each type, the bar length is:

- `n_fixed_diffs`

and the bar colors decompose those fixed differences into:

- `Seen in T1 iSNV`
- `Novel non-APOBEC`
- `Novel APOBEC`

The label `d=...` is the nearest T1/T2 consensus distance.

### Main agreed meaning

This layer is the key longitudinal framework. It asks:

- which types genuinely persist?
- among persistent types, which stay in place?
- which look more like host-internal site transfer?
- which show no exact carryover and therefore require a mutation / swap / intro explanation?

### Patient-level counts from `all_patients_overview_summary_v4.csv`

| Patient | Persist in place | Site transfer | Possible mutation | Introduction | Loss | Persistent both dates |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 6003 | 1 | 0 | 0 | 1 | 9 | 1 |
| 6004 | 23 | 5 | 18 | 31 | 5 | 46 |
| 6005 | 20 | 4 | 8 | 7 | 13 | 32 |
| 6007 | 15 | 1 | 5 | 12 | 0 | 21 |
| 6009 | 12 | 17 | 8 | 2 | 11 | 37 |
| 6020 | 5 | 7 | 3 | 4 | 29 | 15 |
| 6021 | 9 | 3 | 3 | 4 | 4 | 15 |

## 4. Persistent / Changed Types: Whole-Genome Allele-Frequency Layout

### Main directory

`/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4`

### File pattern

Per-type detailed plots are named as:

- `Patient<PatientID>_<Type>_allsite_AF_distribution_v4.png`
- `Patient<PatientID>_<Type>_allsite_AF_distribution_v4.pdf`

Examples:

- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4/Patient6004_HPV120_allsite_AF_distribution_v4.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4/Patient6009_HPV201_allsite_AF_distribution_v4.png`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal_allsite_dynamics_v4/Patient6021_HPV22_allsite_AF_distribution_v4.png`

### Purpose

These plots are the detailed follow-up layer for persistent or changed types. They are used to ask:

- when a type persists, how are variants distributed across all sites?
- are fixed differences in T2 already present as T1 iSNV?
- do changes look like standing variation becoming fixed, or like new sequence change?

### Main meaning

These are the most important figures for separating:

- stable persistence
- subtype replacement / standing variation rise
- more suspicious change that still needs explanation

They are not the first-pass overview; they are the detailed evidence layer for selected types.

## 5. Additional Temporal Mechanism Tables

### Main directory

`/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal7_deep_mining_v1`

### Key files

- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal7_deep_mining_v1/temporal_mechanism_summary_by_patient_v1.csv`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal7_deep_mining_v1/temporal_mechanism_detail_v1.csv`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal7_deep_mining_v1/spatial_same_time_summary_v1.csv`
- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/re-mapping_results_v3/longitudinal7_deep_mining_v1/exact_pair_isnv_similarity_summary_v1.csv`

### Meaning

This directory is the table-heavy quantitative support layer. It is useful when we want:

- 1-10 SNP categorization rather than the stricter 1-5 overview
- standing-variation support counts
- de novo-like counts
- exact-pair iSNV similarity summaries

Important distinction:

- `longitudinal_allsite_dynamics_v4` is the more presentation-ready figure layer
- `longitudinal7_deep_mining_v1` is the denser mechanism table layer

## 6. Recombination-Candidate Screening Figures

### Main root on server

`/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1`

### Final retained nonfragmented longitudinal candidate set

- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/longitudinal/Patient6004_4-6-11_to_9-13-16_T2child`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/longitudinal/Patient6005_7-19-11_to_7-8-13_T2child`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/longitudinal/Patient6009_7-11-13_to_8-6-13_T2child`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/longitudinal/Patient6020_10-5-15_to_11-25-15_T2child`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/longitudinal/Patient6021_11-23-15_to_7-13-16_T2child`

### Retained count after removing obviously fragmented bad plots

- `6004`: `2`
- `6005`: `1`
- `6009`: `8`
- `6020`: `1`
- `6021`: `4`
- total retained longitudinal recombination-like candidates: `16`

### What these plots mean

These are **exploratory mosaic-screening plots**, not proof.

They support the screening-level question:

> Could this child consensus be explained as a mosaic of two parent consensuses from the same patient?

They are useful for:

- visual prioritization
- identifying coherent parent-switch patterns
- deciding which triplets, if any, deserve MSA/SimPlot or read-level follow-up

They should **not** be presented as definitive recombination evidence.

For the detailed panel-by-panel interpretation of these recombination-screening plots, see:

- `/Users/ruixuan/Library/CloudStorage/OneDrive-TheUniversityofHongKong-Connect/HPV_evo/temp/recomb_window_blast_nonfragmented_review_summary.md`

## 7. Practical Reading Order

If the goal is to tell the longitudinal story cleanly, the most defensible order is:

1. `site_consensus_story`  
   Establish whether same-time spatial structure is simple sharing or strong site divergence.

2. `patient_site_ringplots`  
   Show concrete within-time site linkage and potential self-transfer ecology.

3. `Patient*_allsite_dynamics_overview_v4.png`  
   Summarize the cross-time fate of types as persist-in-place, transfer, possible mutation, introduction, and loss.

4. `Patient<Type>_allsite_AF_distribution_v4.png`  
   Deep-dive selected persistent or mutation-like types.

5. `recomb_window_blast_stats_v1` nonfragmented set  
   Only as exploratory candidate screening for possible mosaic children.

## 8. Final Biological Interpretation

The agreed overall interpretation is:

- the first question is not recombination; it is spatial structure
- same-time site structure determines how seriously we can take a later apparent T2 change
- exact persistence across time supports long-term stability
- exact persistence at a different site supports within-host spatial transfer / self-seeding
- non-exact persistent types require deeper variant-level interpretation and may reflect:
  - standing variation becoming fixed
  - subtype replacement
  - more complex unresolved change
- recombination screening is a later, exploratory layer for a minority of candidates, especially among novel or suspicious T2 consensuses

In other words, the longitudinal framework is:

`same-time spatial structure -> cross-time persist/transfer -> variant-level interpretation -> exploratory recombination screening`
