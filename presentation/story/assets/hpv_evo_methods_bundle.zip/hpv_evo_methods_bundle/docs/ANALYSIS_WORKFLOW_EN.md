# HPV_evo Analysis Workflow

## Purpose

This document summarizes the current analysis workflow implemented in the `HPV_evo` research workspace. It is written as an English orientation guide for collaborators, future readers, or manuscript preparation.

The repository is not a packaged software project. It is a research workspace that combines:

- scripts,
- intermediate files,
- result tables,
- figures,
- reference datasets,
- and exploratory analyses.

The core biological goal is to study HPV diversity and within-host dynamics, with special emphasis on:

- public HPV genome context,
- DOCK8 metagenomic skin samples,
- type- and strain-level mapping,
- low-frequency variants,
- APOBEC-like mutational patterns,
- longitudinal retention, replacement, and possible introduction events.

## High-Level Structure

The repository contains four major analysis branches:

1. Public HPV genomes and metadata curation
2. DOCK8 metagenomic read processing and competitive mapping
3. Sample-specific remapping, WG/L1 variant analysis, and three-step retention summaries
4. Phylogenetic, recombination, and visualization branches

In practice, the project has evolved in stages. Some branches are stable and repeatedly used, while others are exploratory or partially standardized.

## Workflow Overview

```mermaid
flowchart TD
    A["Public HPV genomes<br/>NCBI Virus + PaVE"] --> B["Metadata cleaning and harmonization"]
    B --> C["Reference datasets for phylogeny<br/>and comparative context"]

    D["DOCK8 SRA runs"] --> E["FASTQ download"]
    E --> F["Host removal / kneaddata"]
    F --> G["Competitive mapping to multi-HPV reference"]
    G --> H["Coverage and candidate type summaries"]

    H --> I["Sample-specific remapping pipeline"]
    I --> J["Per-type BAM + consensus + LoFreq VCF"]
    J --> K["WG/L1 unified analysis"]
    K --> L["Three-step retention summaries"]

    J --> M["APOBEC enrichment analysis"]
    J --> N["Within-patient phylogeny / branch mutation analysis"]
    J --> O["Longitudinal and site-level interpretation"]
```

## Data Inputs and Reference Assets

### Public HPV genome branch

The public genome branch uses:

- NCBI Virus HPV sequence snapshots
- PaVE reference genomes
- manually cleaned metadata fields such as `Type`, `Group`, `Country`, and modeling `date`

Main files and folders:

- `data/NCBI_20250313/`
- `data/PaVE_20250314/`
- `Rscripts/data_clean_ncbi_20250317.R`
- `Rscripts/data_clean_pave_20250314.R`

Reference libraries for mapping and annotation include:

- `analysis/competitive_mapping/data/hpv_ref_combine.fasta`
- `analysis/competitive_mapping/data/extract_gb_hpv_ref_combine.csv`

These combined references support both competitive mapping and downstream gene/L1 coordinate-based summaries.

### DOCK8 read branch

The DOCK8 branch starts from SRA run tables and paired-end FASTQ files.

Main files and folders:

- `data/DOCK8_sra_nat_med/`
- `data/DOCK8_cell_not_yet/`
- `data/kneaddata/`

Important scripts:

- `data/DOCK8_sra_nat_med/download_script.sh`
- `data/kneaddata/kneaddata_processor.sh`

These scripts assume server-style absolute paths and were designed for batch execution on Ubuntu.

## Branch 1: Public Genome and Metadata Workflow

This branch provides comparative sequence context for HPV evolution analyses.

Main steps:

1. Download HPV sequences and metadata from NCBI Virus and PaVE
2. Clean and standardize metadata fields
3. Merge reference categories such as public genomes, PaVE references, and DOCK8-derived genomes where relevant
4. Generate cleaned FASTA and metadata tables for phylogenetic analyses
5. Build trees or Nextstrain datasets for global context

Typical outputs:

- cleaned metadata tables
- cleaned sequence FASTA files
- Nextstrain-ready metadata
- tree files and Auspice JSON outputs

Main entry points:

- `Rscripts/data_clean_ncbi_20250317.R`
- `analysis/nextstrain/all/Snakefile`
- `analysis/fasttree/auspice/Snakefile`

This branch mainly supports global evolutionary context rather than direct within-host inference.

## Branch 2: DOCK8 Reads to Competitive Mapping

This is the main entry point for sample-level HPV detection in metagenomic reads.

Main steps:

1. Download paired-end FASTQ files from SRA
2. Remove host reads and contamination using `kneaddata`
3. Map cleaned reads competitively against the combined HPV reference database
4. Summarize coverage per sample, virus, and gene
5. Use gene- and L1-level coverage patterns to identify candidate sample-type pairs

Main scripts:

- `data/DOCK8_sra_nat_med/download_script.sh`
- `data/kneaddata/kneaddata_processor.sh`
- `analysis/competitive_mapping/competitive_mapping.sh`
- `analysis/competitive_mapping/coverage_stats.sh`
- `analysis/competitive_mapping/coverage_stats_genes.py`

Key outputs:

- `*_competitive.sorted.bam`
- `*.flagstat`
- `gene_level_coverage_all_metrics.csv`
- `gene_level_coverage_focus_L1.csv`
- sample-level coverage summary tables

Conceptually, this branch is the high-recall screening stage. It is used to detect candidate HPV types in each sample, but not all competitive mapping signals should be interpreted as high-confidence strain evidence.

## Branch 3: Sample-Specific Remapping and WG/L1 Analysis

This branch is the most important part of the current within-host workflow.

It takes sample-type candidates forward into a more specific remapping and variant-calling framework.

### Unified all-patient workflow

The top-level orchestrator is:

- `temp/workflow_all_patients.sh`

It coordinates three stages:

1. remapping and variant calling,
2. unified WG + L1 analysis,
3. optional legacy L1-only analysis.

### Remapping and variant-calling stage

The remapping engine is:

- `temp/pipeline_all_patients.sh`

The practical logic is:

1. Start from per-patient, per-type consensus genomes already organized under `mapped_bams/`
2. Concatenate sample-specific consensus references into a sample-level combined pangenome
3. Remap sample reads back to this combined pangenome
4. Deduplicate alignments
5. Split the remapped BAM by contig/type
6. Run LoFreq to call variants per type

Key per-type outputs:

- `consensus_wg.fa`
- `remap_consensus.bam`
- `lofreq.filtered.vcf`

These outputs live under patient-specific remapping directories and are the basis for downstream WG/L1 analyses.

### Unified WG + L1 analysis stage

The batch runner is:

- `temp/analysis/run_analyze_all.sh`

The main analytical script is:

- `temp/analysis/analyze_all_patients.py`

This stage computes:

- whole-genome SNV counts,
- callable base counts and callable fractions,
- gene-level summaries,
- L1 coordinate-aware summaries,
- APOBEC motif enrichment statistics,
- allele-level supplemental tables,
- per-patient consolidated reports.

Typical output files:

- `final_report_<patient>_WG_L1.csv`
- `final_report_<patient>_WG_L1.alleles.csv`
- `final_report_<patient>_WG_L1.multi_allelic_summary.csv`

Legacy L1-only report generation is also preserved in:

- `temp/run_analyze_all_L1.sh`
- `temp/analyze_all_patients_L1.py`

### What this branch solves

This branch is intended to reduce the limitations of raw competitive mapping by moving to sample-specific references and per-type remapped BAMs. It is the current operational backbone for:

- within-host SNV analysis,
- APOBEC analysis,
- longitudinal comparison,
- and future event classification such as persistence, replacement, or introduction.

## Branch 4: Three-Step Retention Framework

In addition to the engineering pipeline, the repository contains an interpretation layer that summarizes how candidate sample-type pairs survive successive filters.

The main script is:

- `scripts/patient_three_stage_visuals.R`

This script defines a three-step retention framework:

### Step 1: Competitive mapping pass

Input source:

- `analysis/competitive_mapping/gene_level_coverage_all_metrics.csv`

Rule:

- weighted `Mean_Depth >= 10`
- weighted `Cov_Pct_15x >= 10`

Meaning:

- retain candidate sample-type pairs with meaningful support in competitive mapping

### Step 2: WG remapping pass

Input source:

- patient-level final report tables in `temp/re-mapping_results/`

Rule:

- `WG_SNVs > 0`

Meaning:

- retain sample-type pairs that survive sample-specific WG remapping and produce analyzable whole-genome variation

### Step 3: High-confidence retained

Rules:

- must pass Step 2
- `WG_Callable_bp >= 5000`
- `WG_Callable_frac >= 0.8`
- `L1_Callable_bp >= 500`
- `L1_Callable_frac >= 0.5`

Meaning:

- retain only sample-type pairs with enough whole-genome and L1 support for higher-confidence downstream interpretation

Typical outputs:

- `patient_stage_summary.csv`
- `patient_two_visit_deltas.csv`
- `patient_<ID>_stage_dashboard.png`

This three-step framework is not just a shell workflow. It is a retention and interpretability framework layered on top of the remapping pipeline.

## APOBEC and Mutation Interpretation

APOBEC-related analyses are implemented in multiple parts of the repository.

The unified remapping analysis branch computes:

- callable sites,
- motif-specific mutation counts,
- enrichment statistics at WG and L1 levels,
- gene-level APOBEC summaries where coordinates are available.

Within-patient phylogenetic analyses also include branch-level mutation summaries:

- `analysis/dock8_6008_Pt09/summarize_branches.py`
- `analysis/dock8_6004_Pt05/summarize_branches.py`
- `analysis/dock8_6009_Pt10/summarize_branches.py`

These analyses support questions such as:

- whether mutational patterns are APOBEC-like,
- whether changes appear clustered in particular genes or genomic windows,
- and whether longitudinal change is more consistent with persistence, replacement, or newly accumulated variation.

## Phylogeny, Recombination, and Patient-Focused Side Branches

Several directories contain patient-focused or exploratory analyses that extend beyond the core mapping workflow.

Examples include:

- `analysis/dock8_6008_Pt09/`
- `analysis/dock8_6004_Pt05/`
- `analysis/dock8_6009_Pt10/`
- `analysis/nextstrain/`
- `analysis/fasttree/`
- `temp/recomb_screen_pilot/`

These branches cover:

- within-patient phylogenetic trees,
- branch mutation summaries,
- recombination screening,
- exploratory linkage and mosaic analyses,
- site-level and timepoint-level visual summaries.

They should be interpreted as downstream analytical branches built on top of the core mapping and remapping outputs.

## Main Output Layers

The repository produces outputs at several levels:

### Mapping layer

- competitive BAMs
- mapping logs
- flagstat files
- coverage tables

### Remapping layer

- sample-specific consensus FASTA
- remapped per-type BAM
- per-type LoFreq VCF

### Analytical layer

- WG/L1 final reports
- allele tables
- APOBEC summaries
- patient-level retention tables

### Interpretation layer

- patient dashboards
- longitudinal change summaries
- phylogenetic trees
- manuscript and presentation figures

## Current Strengths of the Workflow

The current workflow is strongest in the following areas:

- it integrates public reference context and metagenomic sample analysis in one workspace,
- it distinguishes broad screening from stricter downstream interpretation,
- it uses sample-specific remapping rather than relying only on competitive mapping,
- it explicitly tracks callable coverage and low-power conditions,
- it already supports patient-level and longitudinal summaries.

## Current Caveats and Reproducibility Risks

The workflow should be understood with several caveats:

1. Many scripts use hard-coded absolute paths for Ubuntu server layouts or local OneDrive paths.
2. The environment is not pinned at the repository root.
3. Some branches are stable production-style analysis scripts, while others are exploratory.
4. Naming conventions differ across old and newer outputs.
5. The sample-specific remapping workflow is implemented in practice, but not fully standardized as a single polished package.

These caveats do not invalidate the workflow, but they matter for rerunning, documenting, and publishing the analysis.

## Recommended Reading Order for New Collaborators

For someone new to the repository, the most efficient reading order is:

1. `ai_docs/README.md`
2. `ai_docs/PROJECT_MAP.md`
3. `ai_docs/DATA_PROVENANCE.md`
4. `ai_docs/RUNBOOK.md`
5. `analysis/competitive_mapping/competitive_mapping.sh`
6. `temp/workflow_all_patients.sh`
7. `temp/pipeline_all_patients.sh`
8. `temp/analysis/run_analyze_all.sh`
9. `temp/analysis/analyze_all_patients.py`
10. `scripts/patient_three_stage_visuals.R`

## Summary

The current `HPV_evo` workflow can be summarized as a layered research pipeline:

- a public-genome context branch,
- a DOCK8 competitive-mapping branch,
- a sample-specific remapping and WG/L1 variant-analysis branch,
- and a higher-level interpretation layer for retention, APOBEC, phylogeny, and longitudinal events.

If described in a manuscript, the most defensible framing is:

- competitive mapping for candidate detection,
- sample-specific remapping for higher-specificity variant analysis,
- callable-site-based WG/L1 interpretation,
- and patient-level three-step retention summaries for longitudinal biological interpretation.
