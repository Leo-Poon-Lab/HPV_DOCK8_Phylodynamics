# Recombination Candidate Figures: Final Agreed Paths and Interpretation

## Scope

This note records the final set of figure paths that we agreed to keep, together with the plotting logic, interpretation, and biological meaning of the plots.

These figures are **consensus-level, windowed local-BLAST mosaic screening plots**. They are intended for:

- rapid visual review of candidate mosaic children
- prioritizing triplets for deeper follow-up
- excluding obviously fragmented and uninformative patterns

They are **not** definitive proof of recombination.

## Final Result Root

The final kept figure set is on the server under:

`/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1`

The main nonfragmented summary files are:

- `.../same_time_nonfragmented_summary.tsv`
- `.../longitudinal_nonfragmented_summary.tsv`
- `.../same_time_all_best_triplet_per_child_nonfragmented.tsv`
- `.../longitudinal_all_best_triplet_per_child_nonfragmented.tsv`

For each dataset that retained nonfragmented figures, the useful files are:

- `best_triplet_per_child_nonfragmented.tsv`
- `best_triplet_plot_manifest_nonfragmented.tsv`
- `best_triplet_plots_nonfragmented/`

## Final Figure Directories

### Longitudinal

These are the longitudinal datasets that still retained nonfragmented candidate plots:

- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/longitudinal/Patient6004_4-6-11_to_9-13-16_T2child`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/longitudinal/Patient6005_7-19-11_to_7-8-13_T2child`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/longitudinal/Patient6009_7-11-13_to_8-6-13_T2child`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/longitudinal/Patient6020_10-5-15_to_11-25-15_T2child`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/longitudinal/Patient6021_11-23-15_to_7-13-16_T2child`

Retained counts:

- `6004`: `2 / 113`
- `6005`: `1 / 51`
- `6009`: `8 / 50`
- `6020`: `1 / 23`
- `6021`: `4 / 15`

Total longitudinal retained after nonfragmented filtering:

- `16 / 311`

### Same-Time

These are the same-time datasets that still retained nonfragmented candidate plots:

- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/same_time/Patient6008_6-11-13`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/same_time/Patient6009_7-11-13`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/same_time/Patient6010_3-31-14`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/same_time/Patient6011_4-7-14`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/same_time/Patient6012_6-20-14`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/same_time/Patient6013_11-12-14`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/same_time/Patient6014_1-21-15`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/same_time/Patient6015_1-16-15`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/same_time/Patient6020_10-5-15`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/same_time/Patient6021_11-23-15`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/same_time/Patient6025_8-10-16`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/same_time/Patient6026_10-26-16`

Total same-time retained after nonfragmented filtering:

- `169 / 2085`

## Final Screening Logic We Agreed To Use

### Step 1: best parent pair per child

For each child sequence, only one best parent pair was kept in `best_triplet_per_child.tsv`.

This means the final retained plots are **not** multiple parent pairs for the same child; they are already reduced to one representative triplet per child.

### Step 2: remove obviously fragmented bad plots

We agreed to remove plots that looked like noisy, broken, rapidly alternating mosaics.

The practical nonfragmented filter was:

- `switch_count <= 6`
- `fragmentation <= 0.35`

where:

- `switch_count` = number of A/B winner changes along the child genome
- `fragmentation = switch_count / (n_a_windows + n_b_windows - 1)`

This filter was chosen specifically to remove plots where the winner alternated too frequently to be biologically interpretable.

## What Each Plot Actually Quantifies

Each figure has three panels. All three are based on **sliding-window local BLAST** on the child consensus sequence.

Shared settings:

- `window = 200 bp`
- `step = 50 bp`
- windows with too many `N` are excluded
- only BLAST hits passing the plotting thresholds are used

Important: these figures are **not based on MSA** and **not based on read depth**.

### Panel 1: Identity (%)

This panel shows, for each child window:

- local BLAST `pident` between child and Parent A
- local BLAST `pident` between child and Parent B

Interpretation:

- higher blue line means that local window looks more similar to Parent A
- higher orange line means that local window looks more similar to Parent B
- broken lines indicate windows without a valid BLAST hit for that parent under the current thresholds

Biological meaning:

- this panel is the local sequence similarity landscape
- it asks whether different parts of the child consensus resemble different parent candidates

### Panel 2: Qcov (%)

This panel shows, for each child window:

- BLAST `qcovhsp` for Parent A
- BLAST `qcovhsp` for Parent B

Interpretation:

- this is the fraction of the child window covered by the best local BLAST alignment
- higher values mean that the local comparison is more complete and less fragmentary

Critical clarification:

- this is **not sequencing depth**
- this is **not mapping coverage**
- this is only local BLAST query coverage

Biological meaning:

- this panel indicates whether a local similarity signal is based on a reasonably complete local match, rather than a very short or broken alignment

### Panel 3: Winner

Each child window is assigned one of three states:

- `A`: Parent A is the better local hit
- `B`: Parent B is the better local hit
- `AMBIG`: no valid winner or tie / insufficient distinction

Winner is assigned using the best local hit comparison, prioritizing:

- `bitscore`
- then `pident`
- then `qcovhsp`

Color meaning:

- blue = A wins
- orange = B wins
- grey = ambiguous / low-information

Transparency:

- stronger opacity reflects higher local BLAST query coverage for the winning parent

Biological meaning:

- this panel is the most direct mosaic summary
- it shows whether the child genome is organized into coherent A-like and B-like blocks

## How We Agreed To Read These Figures

### Useful pattern

A plot is worth follow-up if it shows:

- relatively coherent A-like block(s)
- relatively coherent B-like block(s)
- a limited number of switches
- local similarity and coverage that are not purely broken and discontinuous

This is the type of pattern that is compatible with a candidate mosaic child.

### Uninformative pattern

A plot is not useful if:

- A and B alternate constantly in tiny fragments
- there are too many switches
- most windows are broken or low-information
- the apparent support comes from many scattered windows rather than coherent blocks

This is why we removed obviously fragmented figures before manual review.

## What These Figures Mean Biologically

These plots support a **screening-level question**:

> Could this child consensus be explained as a mosaic of two candidate parent consensuses within the same patient?

They are useful for:

- prioritizing triplets for follow-up
- identifying candidate recombinant-like children
- separating coherent mosaic patterns from random fragmented local homology

They do **not** by themselves prove:

- true intrahost recombination
- breakpoint accuracy
- read-level recombinant haplotypes
- parent truth in a strict causal sense

At this stage, the figures should be described as:

- `mosaic-like candidate screening plots`
- `local similarity support plots`
- `triplet-based candidate recombination visualizations`

not as definitive recombination evidence.

## Recommended Use in the Project

The most defensible use of these figures is:

1. first-pass manual review of retained nonfragmented candidates
2. prioritization of a small number of longitudinal candidates
3. optional next-step validation with:
   - triplet MSA + SimPlot / BootScan style analysis
   - read-level follow-up
   - more careful homology-aware breakpoint analysis

## Most Relevant Current Longitudinal Set

For immediate manual review, the most relevant retained longitudinal figure folders are:

- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/longitudinal/Patient6009_7-11-13_to_8-6-13_T2child`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/longitudinal/Patient6021_11-23-15_to_7-13-16_T2child`
- `/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction/sample_specific_remapping/recomb_window_blast_stats_v1/longitudinal/Patient6004_4-6-11_to_9-13-16_T2child`

These survived the nonfragmented filter and are therefore the most reasonable starting point for visual inspection.
