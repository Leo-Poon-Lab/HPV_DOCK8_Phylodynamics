#!/bin/bash

# ==============================================================================
# Script Name: competitive_mapping.sh
# Description: Competitive mapping using further cleaned reads (no bacteria/fungi)
# Input Dir:   /home/ubuntu/HPV_evo/kneaddata_further
# Output Dir:  /home/ubuntu/HPV_evo/ref_assembly/mapping_results
# ==============================================================================

# --- Configuration ---
WORK_DIR="/home/ubuntu/HPV_evo/ref_assembly"
# 路径更新：指向进一步去除污染后的数据
INPUT_DIR="/home/ubuntu/HPV_evo/kneaddata_further"
OUTPUT_DIR="${WORK_DIR}/mapping_results"
# 参考序列文件名
REF_FASTA="${WORK_DIR}/hpv_ref_combine.fasta"
INDEX_NAME="hpv_all_db"
THREADS=40 # 既然你之前构建索引用了40线程，这里也设为40提高速度
LOG_FILE="${WORK_DIR}/competitive_mapping.log"

# --- Setup ---
mkdir -p "${OUTPUT_DIR}"
cd "${WORK_DIR}" || exit 1

# 开始日志记录
exec > >(tee -a "${LOG_FILE}") 2>&1
echo "=== Competitive Mapping (V2) Started at $(date) ==="
echo "Input Source: ${INPUT_DIR}"
echo "Using Reference: ${REF_FASTA}"

# --- Step 1: Build/Check Index ---
if [ ! -f "${REF_FASTA}" ]; then
    echo "Error: Reference ${REF_FASTA} not found!"
    exit 1
fi

if [ ! -f "${INDEX_NAME}.1.bt2" ]; then
    echo "Building Bowtie2 index..."
    bowtie2-build --threads "${THREADS}" "${REF_FASTA}" "${INDEX_NAME}"
fi

# --- Step 2: Mapping Loop ---
echo "--- Starting Mapping for all samples ---"

# 修改匹配模式为: _final_paired_1.fastq
find "${INPUT_DIR}" -name "*_final_paired_1.fastq" | sort | while read -r R1_FILE; do
    
    # 提取样本ID (例如 MET1074)
    BASENAME=$(basename "${R1_FILE}")
    SAMPLE_ID="${BASENAME%_final_paired_1.fastq}"
    
    R2_FILE="${INPUT_DIR}/${SAMPLE_ID}_final_paired_2.fastq"
    SAM_OUT="${OUTPUT_DIR}/${SAMPLE_ID}_competitive.sam"
    BAM_SORTED="${OUTPUT_DIR}/${SAMPLE_ID}_competitive.sorted.bam"
    
    echo "Processing: ${SAMPLE_ID}"
    
    if [ ! -f "${R2_FILE}" ]; then
        echo "  [Skip] R2 file missing for ${SAMPLE_ID}"
        continue
    fi

    # 执行比对
    # 使用 --very-sensitive-local 捕捉高度变异的 HPV reads
    bowtie2 -x "${INDEX_NAME}" \
        -1 "${R1_FILE}" \
        -2 "${R2_FILE}" \
        --very-sensitive-local \
        --no-unal \
        --threads "${THREADS}" \
        -S "${SAM_OUT}"
        
    if [ $? -eq 0 ]; then
        # 转为排序好的 BAM 并建立索引
        samtools view -@ "${THREADS}" -bS "${SAM_OUT}" | \
        samtools sort -@ "${THREADS}" -o "${BAM_SORTED}"
        
        samtools index -@ "${THREADS}" "${BAM_SORTED}"
        
        # 统计简报
        samtools flagstat "${BAM_SORTED}" > "${OUTPUT_DIR}/${SAMPLE_ID}.flagstat"
        
        # 删除巨大的中间 SAM 文件
        rm -f "${SAM_OUT}"
        echo "  [Done] ${SAMPLE_ID} processed successfully."
    else
        echo "  [Error] Bowtie2 failed for ${SAMPLE_ID}."
    fi

done

echo "=== All Tasks Finished at $(date) ==="
