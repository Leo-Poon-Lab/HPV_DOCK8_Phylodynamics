#!/bin/bash
set -uo pipefail
shopt -s nullglob

# ==============================================================================
# HPV Sample-Specific Re-mapping Pipeline - ALL PATIENTS (Standalone)
# ==============================================================================
# This script runs remapping/calling for all numeric patient folders under
# mapped_bams/.
# Logs:
#   - master log: ${OUTPUT_ROOT}/pipeline_all_*.log
#   - patient log: ${OUTPUT_ROOT}/${patient_id}/pipeline_${patient_id}_*.log
# ==============================================================================

# --- Config (override by env if needed) ---
BASE_DIR="${BASE_DIR:-/home/ubuntu/HPV_evo/ref_assembly/strain_reconstruction}"
INPUT_META="${INPUT_META:-${BASE_DIR}/inputs/user_samples_meta_refined.csv}"
MAPPED_BAMS_ROOT="${MAPPED_BAMS_ROOT:-${BASE_DIR}/mapped_bams}"
OUTPUT_ROOT="${OUTPUT_ROOT:-${BASE_DIR}/sample_specific_remapping}"
READS_DIR="${READS_DIR:-/home/ubuntu/HPV_evo/kneaddata/merged/repaired}"

# Tools
BOWTIE2="${BOWTIE2:-/usr/bin/bowtie2}"
BOWTIE2_BUILD="${BOWTIE2_BUILD:-/usr/bin/bowtie2-build}"
SAMTOOLS="${SAMTOOLS:-/usr/bin/samtools}"
LOFREQ="${LOFREQ:-/usr/local/bin/lofreq}"

THREADS="${THREADS:-8}"
MIN_MAPQ="${MIN_MAPQ:-20}"

# Toggles
SKIP_COMPLETED="${SKIP_COMPLETED:-1}"

# Exit code used internally to mark "skip" in patient subshell
SKIP_CODE=100

log()  { echo "[$(date '+%F %T')] [INFO]  $*"; }
warn() { echo "[$(date '+%F %T')] [WARN]  $*"; }
err()  { echo "[$(date '+%F %T')] [ERROR] $*"; }

require_file() {
    local p="$1"
    local name="$2"
    if [[ ! -f "$p" ]]; then
        err "${name} not found: ${p}"
        exit 1
    fi
}

require_exec() {
    local p="$1"
    local name="$2"
    if [[ ! -x "$p" ]]; then
        err "${name} not executable: ${p}"
        exit 1
    fi
}

patient_complete() {
    # Returns 0 if patient remap/call outputs are complete.
    local input_bams_dir="$1"
    local output_dir="$2"

    local expected=0
    local ready=0
    local in_type_dir out_type_dir

    for in_type_dir in "${input_bams_dir}"/*_*; do
        [[ -d "$in_type_dir" && -s "${in_type_dir}/consensus_wg.fa" ]] || continue
        ((expected++))
        out_type_dir="${output_dir}/$(basename "$in_type_dir")"
        if [[ -s "${out_type_dir}/remap_consensus.bam" && -s "${out_type_dir}/lofreq.filtered.vcf" ]]; then
            ((ready++))
        fi
    done

    [[ "$expected" -gt 0 ]] || return 1
    [[ "$ready" -eq "$expected" ]]
}

# --- Preflight ---
mkdir -p "${OUTPUT_ROOT}"
MASTER_LOG="${OUTPUT_ROOT}/pipeline_all_$(date +%Y%m%d_%H%M%S).log"

{
    log "=== Starting Pipeline for ALL Patients (Standalone) ==="
    log "MASTER_LOG:       ${MASTER_LOG}"
    log "BASE_DIR:         ${BASE_DIR}"
    log "INPUT_META:       ${INPUT_META}"
    log "MAPPED_BAMS_ROOT: ${MAPPED_BAMS_ROOT}"
    log "OUTPUT_ROOT:      ${OUTPUT_ROOT}"
    log "READS_DIR:        ${READS_DIR}"
    log "SKIP_COMPLETED:   ${SKIP_COMPLETED}"
} | tee -a "$MASTER_LOG"

require_file "$INPUT_META" "INPUT_META"
if [[ ! -d "$MAPPED_BAMS_ROOT" ]]; then
    err "MAPPED_BAMS_ROOT not found: ${MAPPED_BAMS_ROOT}" | tee -a "$MASTER_LOG"
    exit 1
fi
require_exec "$BOWTIE2" "BOWTIE2"
require_exec "$BOWTIE2_BUILD" "BOWTIE2_BUILD"
require_exec "$SAMTOOLS" "SAMTOOLS"
require_exec "$LOFREQ" "LOFREQ"

# --- Build Patient -> Samples mapping from CSV ---
declare -A PATIENT_SAMPLES
while IFS=, read -r sample_id patient_id _rest; do
    sample_id="${sample_id//$'\r'/}"
    patient_id="${patient_id//$'\r'/}"
    [[ "$sample_id" == "SampleID" ]] && continue
    [[ -z "$sample_id" || -z "$patient_id" ]] && continue

    if [[ -n "${PATIENT_SAMPLES[$patient_id]+x}" ]]; then
        case " ${PATIENT_SAMPLES[$patient_id]} " in
            *" ${sample_id} "*) ;;
            *) PATIENT_SAMPLES[$patient_id]="${PATIENT_SAMPLES[$patient_id]} ${sample_id}" ;;
        esac
    else
        PATIENT_SAMPLES[$patient_id]="$sample_id"
    fi
done < "$INPUT_META"

# --- Global counters ---
global_patient_ok=0
global_patient_skip=0
global_patient_fail=0
seen_patient_dirs=0

# --- Iterate patients discovered from mapped_bams ---
for patient_dir in "${MAPPED_BAMS_ROOT}"/*/; do
    [[ -d "$patient_dir" ]] || continue
    ((seen_patient_dirs++))

    patient_id="$(basename "$patient_dir")"
    input_bams_dir="${MAPPED_BAMS_ROOT}/${patient_id}"
    output_dir="${OUTPUT_ROOT}/${patient_id}"
    mkdir -p "$output_dir"

    patient_log="${output_dir}/pipeline_${patient_id}_$(date +%Y%m%d_%H%M%S).log"

    if (
        set -uo pipefail
        exec > >(tee -a "$MASTER_LOG" "$patient_log") 2>&1

        log "=========================================================="
        log "=== Patient ${patient_id} ==="
        log "INPUT_BAMS_DIR: ${input_bams_dir}"
        log "OUTPUT_DIR:     ${output_dir}"
        log "PATIENT_LOG:    ${patient_log}"
        log "=========================================================="

        if [[ ! "$patient_id" =~ ^[0-9]+$ ]]; then
            warn "Non-numeric folder under mapped_bams: ${patient_id}. Skipping."
            exit "$SKIP_CODE"
        fi

        if [[ -z "${PATIENT_SAMPLES[$patient_id]+x}" ]]; then
            warn "Patient ${patient_id} exists in mapped_bams but not in CSV. Skipping."
            exit "$SKIP_CODE"
        fi

        if [[ "$SKIP_COMPLETED" == "1" ]] && patient_complete "$input_bams_dir" "$output_dir"; then
            log "[SKIP] Patient ${patient_id}: outputs already complete."
            exit "$SKIP_CODE"
        fi

        read -ra samples <<< "${PATIENT_SAMPLES[$patient_id]}"
        sample_ok=0
        sample_failed=0
        sample_skipped=0
        type_ok=0
        type_failed=0
        type_skipped=0

        for sample_id in "${samples[@]}"; do
            log ">>> Processing Sample: ${sample_id} (Patient ${patient_id})"

            merge_dir="${output_dir}/${sample_id}_combined_ref"
            mkdir -p "$merge_dir"
            combined_ref="${merge_dir}/combined_consensus.fa"
            : > "$combined_ref"

            found_any=0
            for type_dir in "${input_bams_dir}/${sample_id}_"*; do
                [[ -d "$type_dir" ]] || continue
                cons_file="${type_dir}/consensus_wg.fa"
                if [[ -s "$cons_file" ]]; then
                    cat "$cons_file" >> "$combined_ref"
                    found_any=1
                fi
            done

            if [[ "$found_any" -eq 0 ]]; then
                warn "No consensus genomes found for ${sample_id}. Skipping sample."
                ((sample_skipped++))
                continue
            fi

            sample_upper=$(echo "$sample_id" | tr '[:lower:]' '[:upper:]')
            r1="${READS_DIR}/${sample_upper}_R1.fastq"
            r2="${READS_DIR}/${sample_upper}_R2.fastq"
            if [[ ! -f "$r1" || ! -f "$r2" ]]; then
                err "Reads not found for ${sample_id}: $r1 / $r2"
                ((sample_failed++))
                continue
            fi

            combined_idx="${merge_dir}/pangenome_idx"
            combined_bam_raw="${merge_dir}/competitive_all_raw.bam"
            combined_bam_dedup="${merge_dir}/competitive_all.dedup.bam"

            log "  -> Mapping..."
            if ! "$BOWTIE2_BUILD" "$combined_ref" "$combined_idx"; then
                err "bowtie2-build failed for ${sample_id}"
                ((sample_failed++))
                continue
            fi
            if ! "$BOWTIE2" -x "$combined_idx" -1 "$r1" -2 "$r2" --local --no-unal -p "$THREADS" | \
                 "$SAMTOOLS" sort -@ "$THREADS" -o "$combined_bam_raw"; then
                err "Competitive mapping failed for ${sample_id}"
                ((sample_failed++))
                continue
            fi
            if ! "$SAMTOOLS" index "$combined_bam_raw"; then
                err "samtools index failed for ${sample_id} raw BAM"
                ((sample_failed++))
                continue
            fi

            log "  -> Deduplicating..."
            if ! "$SAMTOOLS" sort -n -@ "$THREADS" "$combined_bam_raw" | \
                 "$SAMTOOLS" fixmate -m - - | \
                 "$SAMTOOLS" sort -@ "$THREADS" - | \
                 "$SAMTOOLS" markdup -r -@ "$THREADS" - "$combined_bam_dedup"; then
                err "Dedup pipeline failed for ${sample_id}"
                ((sample_failed++))
                continue
            fi
            if ! "$SAMTOOLS" index "$combined_bam_dedup"; then
                err "samtools index failed for ${sample_id} dedup BAM"
                ((sample_failed++))
                continue
            fi

            log "  -> Splitting & Calling Variants..."
            sample_type_success=0

            for type_dir in "${input_bams_dir}/${sample_id}_"*; do
                [[ -d "$type_dir" ]] || continue
                dirname="$(basename "$type_dir")"
                target_dir="${output_dir}/${dirname}"
                mkdir -p "$target_dir"

                cons_file="${type_dir}/consensus_wg.fa"
                if [[ ! -s "$cons_file" ]]; then
                    warn "Skip ${dirname}: missing/empty consensus_wg.fa"
                    ((type_skipped++))
                    continue
                fi

                seq_name=$(awk '/^>/{gsub(/^>/,"",$1); print $1; exit}' "$cons_file")
                if [[ -z "$seq_name" ]]; then
                    warn "Skip ${dirname}: cannot parse FASTA header"
                    ((type_skipped++))
                    continue
                fi

                final_bam="${target_dir}/remap_consensus.bam"
                cp -f "$cons_file" "${target_dir}/consensus_wg.fa"
                ref_file="${target_dir}/consensus_wg.fa"
                if ! "$SAMTOOLS" faidx "$ref_file"; then
                    err "faidx failed for ${dirname}"
                    ((type_failed++))
                    continue
                fi

                if ! "$SAMTOOLS" view -q "$MIN_MAPQ" -b "$combined_bam_dedup" "$seq_name" > "$final_bam"; then
                    warn "Skip ${dirname}: samtools view failed on contig ${seq_name}"
                    rm -f "$final_bam"
                    ((type_failed++))
                    continue
                fi
                if [[ ! -s "$final_bam" ]]; then
                    warn "Skip ${dirname}: no mapped reads after region split (${seq_name})"
                    rm -f "$final_bam"
                    ((type_skipped++))
                    continue
                fi
                if ! "$SAMTOOLS" index "$final_bam"; then
                    err "samtools index failed for ${dirname} final BAM"
                    ((type_failed++))
                    continue
                fi

                bam_indel="${target_dir}/remap_indelqual.bam"
                vcf_raw="${target_dir}/lofreq.raw.vcf"
                vcf_clean="${target_dir}/lofreq.filtered.vcf"

                rm -f "$bam_indel" "$bam_indel.bai"
                if ! "$LOFREQ" indelqual --dindel -f "$ref_file" -o "$bam_indel" "$final_bam"; then
                    warn "Skip ${dirname}: lofreq indelqual failed"
                    ((type_failed++))
                    continue
                fi
                if ! "$SAMTOOLS" index "$bam_indel"; then
                    warn "Skip ${dirname}: samtools index on indel BAM failed"
                    ((type_failed++))
                    continue
                fi

                if ! "$LOFREQ" call --call-indels --min-mq 20 --min-bq 20 --min-alt-bq 20 --min-cov 20 \
                    -f "$ref_file" -o "$vcf_raw" "$bam_indel"; then
                    warn "Skip ${dirname}: lofreq call failed"
                    ((type_failed++))
                    continue
                fi

                n_raw=$(awk 'BEGIN{n=0}!/^#/{n++}END{print n+0}' "$vcf_raw")
                if ! awk '($1 ~ /^#/) || ($7 == "PASS")' "$vcf_raw" > "$vcf_clean"; then
                    warn "Skip ${dirname}: PASS filter step failed"
                    ((type_failed++))
                    continue
                fi
                n_clean=$(awk 'BEGIN{n=0}!/^#/{n++}END{print n+0}' "$vcf_clean")
                n_dropped=$((n_raw - n_clean))
                log "    VCF QC ${dirname}: Raw=${n_raw} | Clean=${n_clean} | Dropped=${n_dropped}"
                if [[ "$n_dropped" -gt 0 ]]; then
                    warn "Dropped ${n_dropped} non-PASS variants for ${dirname}"
                fi

                rm -f "$bam_indel" "$bam_indel.bai"
                ((type_ok++))
                ((sample_type_success++))
                log "    Processed: ${dirname}"
            done

            if [[ "$sample_type_success" -eq 0 ]]; then
                warn "Sample ${sample_id} finished but no type completed successfully."
                ((sample_skipped++))
            else
                ((sample_ok++))
                log "Sample ${sample_id} completed with ${sample_type_success} successful type(s)."
            fi
        done

        if [[ "$type_ok" -eq 0 ]]; then
            err "Patient ${patient_id}: no type completed successfully."
            exit 2
        fi

        log "=== Patient ${patient_id} Completed ==="
        log "  Sample summary: OK=${sample_ok} | FAILED=${sample_failed} | SKIPPED=${sample_skipped}"
        log "  Type summary:   OK=${type_ok} | FAILED=${type_failed} | SKIPPED=${type_skipped}"
        exit 0
    ); then
        ((global_patient_ok++))
    else
        rc=$?
        if [[ "$rc" -eq "$SKIP_CODE" ]]; then
            ((global_patient_skip++))
        else
            ((global_patient_fail++))
        fi
    fi
done

if [[ "$seen_patient_dirs" -eq 0 ]]; then
    warn "No patient directories found under ${MAPPED_BAMS_ROOT}" | tee -a "$MASTER_LOG"
fi

{
    log "=========================================================="
    log "=== ALL PATIENTS FINISHED ==="
    log "  Patients OK:       ${global_patient_ok}"
    log "  Patients Skipped:  ${global_patient_skip}"
    log "  Patients Failed:   ${global_patient_fail}"
    log "  Master log:        ${MASTER_LOG}"
    log "=========================================================="
} | tee -a "$MASTER_LOG"
