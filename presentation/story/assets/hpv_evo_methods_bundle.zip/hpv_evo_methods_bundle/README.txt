HPV_evo methods bundle for the internal update page.

Contents are grouped by workflow stage:
01_input_preparation
02_assembly_recovery
03_mapping_backbone
04_callable_analysis
05_recombination_screen
docs
