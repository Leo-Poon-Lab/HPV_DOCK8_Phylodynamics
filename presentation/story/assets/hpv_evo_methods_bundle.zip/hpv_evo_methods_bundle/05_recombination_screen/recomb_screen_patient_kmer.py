#!/usr/bin/env python3
import argparse
import csv
import itertools
import math
import re
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle


GENE_ORDER = ["E6", "E7", "E1", "E2", "E4", "E5", "L2", "L1", "URR"]


def parse_args():
    parser = argparse.ArgumentParser(
        description="Patient-internal whole-genome recombination screening from merged consensus FASTA."
    )
    parser.add_argument("--fasta", required=True)
    parser.add_argument("--msk-meta", required=True)
    parser.add_argument("--pave-gff-dir", required=True)
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--window", type=int, default=400)
    parser.add_argument("--step", type=int, default=100)
    parser.add_argument("--k", type=int, default=15)
    parser.add_argument("--top-donors", type=int, default=6)
    parser.add_argument("--min-global-score", type=float, default=0.03)
    parser.add_argument("--min-local-score", type=float, default=0.18)
    parser.add_argument("--min-margin", type=float, default=0.03)
    parser.add_argument("--min-block-windows", type=int, default=2)
    parser.add_argument("--min-parent-frac", type=float, default=0.15)
    parser.add_argument("--max-plots", type=int, default=8)
    return parser.parse_args()


def read_fasta(path):
    records = []
    header = None
    seq_lines = []
    with open(path) as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                if header is not None:
                    records.append((header, "".join(seq_lines).upper()))
                header = line[1:]
                seq_lines = []
            else:
                seq_lines.append(line)
        if header is not None:
            records.append((header, "".join(seq_lines).upper()))
    return records


def parse_header(header):
    parts = header.split("|")
    if len(parts) != 5:
        raise ValueError(f"Unexpected header format: {header}")
    patient, sample_id, site, typ, date = parts
    return {
        "header": header,
        "patient": patient,
        "sample_id": sample_id,
        "site": site,
        "type": typ,
        "date": date,
    }


def kmer_set(seq, k):
    kmers = set()
    limit = len(seq) - k + 1
    if limit < 1:
        return kmers
    for i in range(limit):
        kmer = seq[i : i + k]
        if "N" in kmer:
            continue
        kmers.add(kmer)
    return kmers


def window_kmers(seq, start, end, k):
    sub = seq[start:end]
    kmers = set()
    limit = len(sub) - k + 1
    if limit < 1:
        return kmers
    for i in range(limit):
        kmer = sub[i : i + k]
        if "N" in kmer:
            continue
        kmers.add(kmer)
    return kmers


def non_n_fraction(seq):
    if not seq:
        return 0.0
    good = sum(1 for ch in seq if ch != "N")
    return good / len(seq)


def short_label(meta):
    return f"{meta['sample_id']}/{meta['site']}/{meta['type']}"


def load_msk_coords(path):
    out = {}
    with open(path) as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            virus = row["Virus"]
            genes = []
            for key, value in row.items():
                if not key.endswith("_Start"):
                    continue
                gene = key[: -len("_Start")]
                end_key = gene + "_End"
                if not row.get(end_key):
                    continue
                if not value:
                    continue
                try:
                    start = int(float(value))
                    end = int(float(row[end_key]))
                except ValueError:
                    continue
                if start <= 0 or end <= 0:
                    continue
                genes.append((gene, start, end))
            out[virus] = dedupe_gene_coords(genes)
    return out


def dedupe_gene_coords(genes):
    seen = {}
    for gene, start, end in genes:
        gene = gene.replace("^", "^")
        old = seen.get((gene, start, end))
        if old is None:
            seen[(gene, start, end)] = (gene, start, end)
    vals = list(seen.values())
    vals.sort(key=lambda x: (gene_rank(x[0]), x[1], x[2]))
    return vals


def gene_rank(gene):
    gene_clean = gene.split("^")[0]
    try:
        return GENE_ORDER.index(gene_clean)
    except ValueError:
        return len(GENE_ORDER) + 1


def load_pave_coords(gff_dir):
    out = {}
    gff_dir = Path(gff_dir)
    for gff in gff_dir.glob("*.gff"):
        typ = gff.name.replace("REF.gff", "").replace(".gff", "")
        genes = []
        with gff.open() as handle:
            for raw in handle:
                if not raw or raw.startswith("#"):
                    continue
                parts = raw.rstrip("\n").split("\t")
                if len(parts) < 9:
                    continue
                feature = parts[2]
                if feature != "gene":
                    continue
                start = int(parts[3])
                end = int(parts[4])
                attrs = parts[8]
                m = re.search(r"Name=([^;]+)", attrs)
                if not m:
                    continue
                gene = m.group(1)
                genes.append((gene, start, end))
        out[typ] = dedupe_gene_coords(genes)
    return out


def global_score(a, b):
    if not a:
        return 0.0
    return len(a & b) / len(a)


def segment_windows(length, window, step):
    starts = list(range(0, max(1, length - window + 1), step))
    if not starts:
        starts = [0]
    last_end = starts[-1] + window
    if last_end < length:
        starts.append(max(0, length - window))
    return [(s, min(length, s + window)) for s in starts]


def scan_recipient(rec, all_records, args):
    donor_candidates = []
    for donor in all_records:
        if donor["header"] == rec["header"]:
            continue
        score = global_score(rec["global_kmers"], donor["global_kmers"])
        if score >= args.min_global_score:
            donor_candidates.append((score, donor))
    donor_candidates.sort(key=lambda x: x[0], reverse=True)
    donor_candidates = donor_candidates[: args.top_donors]

    base_windows = []
    for idx, (start, end) in enumerate(segment_windows(len(rec["seq"]), args.window, args.step), start=1):
        kmers = window_kmers(rec["seq"], start, end, args.k)
        valid_frac = non_n_fraction(rec["seq"][start:end])
        row = {
            "window_index": idx,
            "start": start + 1,
            "end": end,
            "mid": (start + 1 + end) / 2.0,
            "valid_frac": valid_frac,
            "kmer_count": len(kmers),
            "kmers": kmers,
            "usable": len(kmers) >= 10 and valid_frac >= 0.65,
        }
        base_windows.append(row)

    best_model = None
    donors_only = [donor for _, donor in donor_candidates]
    for parent_a, parent_b in itertools.combinations(donors_only, 2):
        model = evaluate_parent_pair(rec, base_windows, parent_a, parent_b, args)
        if best_model is None or model_rank(model) > model_rank(best_model):
            best_model = model

    if best_model is None:
        best_model = {
            "parent_a": None,
            "parent_b": None,
            "windows": evaluate_parent_pair(rec, base_windows, None, None, args)["windows"],
            "blocks": [],
            "strong_blocks": [],
            "candidate": False,
            "informative_bp": 0,
            "informative_frac": 0.0,
            "switches": 0,
            "parent_a_bp": 0,
            "parent_b_bp": 0,
            "parent_a_frac": 0.0,
            "parent_b_frac": 0.0,
        }

    return donor_candidates, best_model


def evaluate_parent_pair(rec, base_windows, parent_a, parent_b, args):
    windows = []
    for base in base_windows:
        row = {
            "window_index": base["window_index"],
            "start": base["start"],
            "end": base["end"],
            "mid": base["mid"],
            "valid_frac": base["valid_frac"],
            "kmer_count": base["kmer_count"],
            "parent_a": parent_a["header"] if parent_a else "",
            "parent_b": parent_b["header"] if parent_b else "",
            "score_parent_a": 0.0,
            "score_parent_b": 0.0,
            "chosen_parent": "LOW_INFO",
            "chosen_score": 0.0,
            "score_gap": 0.0,
        }
        if parent_a is None or parent_b is None or not base["usable"]:
            windows.append(row)
            continue
        score_a = global_score(base["kmers"], parent_a["global_kmers"])
        score_b = global_score(base["kmers"], parent_b["global_kmers"])
        row["score_parent_a"] = score_a
        row["score_parent_b"] = score_b
        row["score_gap"] = abs(score_a - score_b)
        top_score = max(score_a, score_b)
        if top_score < args.min_local_score or row["score_gap"] < args.min_margin:
            row["chosen_parent"] = "AMBIG"
            row["chosen_score"] = top_score
        elif score_a > score_b:
            row["chosen_parent"] = "PARENT_A"
            row["chosen_score"] = score_a
        else:
            row["chosen_parent"] = "PARENT_B"
            row["chosen_score"] = score_b
        windows.append(row)

    blocks = build_blocks(windows, len(rec["seq"]), label_key="chosen_parent", score_key="chosen_score", margin_key="score_gap")
    strong_blocks = [
        block
        for block in blocks
        if block["label"] in {"PARENT_A", "PARENT_B"} and block["n_windows"] >= args.min_block_windows
    ]
    informative_bp = sum(block["span_bp"] for block in strong_blocks)
    parent_a_bp = sum(block["span_bp"] for block in strong_blocks if block["label"] == "PARENT_A")
    parent_b_bp = sum(block["span_bp"] for block in strong_blocks if block["label"] == "PARENT_B")
    donor_runs = [block["label"] for block in strong_blocks]
    switches = sum(1 for i in range(1, len(donor_runs)) if donor_runs[i] != donor_runs[i - 1])
    informative_frac = informative_bp / len(rec["seq"]) if rec["seq"] else 0.0
    parent_a_frac = parent_a_bp / informative_bp if informative_bp else 0.0
    parent_b_frac = parent_b_bp / informative_bp if informative_bp else 0.0
    candidate = (
        parent_a is not None
        and parent_b is not None
        and parent_a_bp > 0
        and parent_b_bp > 0
        and switches >= 1
        and informative_frac >= 0.35
        and parent_a_frac >= args.min_parent_frac
        and parent_b_frac >= args.min_parent_frac
    )
    return {
        "parent_a": parent_a,
        "parent_b": parent_b,
        "windows": windows,
        "blocks": blocks,
        "strong_blocks": strong_blocks,
        "candidate": candidate,
        "informative_bp": informative_bp,
        "informative_frac": informative_frac,
        "switches": switches,
        "parent_a_bp": parent_a_bp,
        "parent_b_bp": parent_b_bp,
        "parent_a_frac": parent_a_frac,
        "parent_b_frac": parent_b_frac,
    }


def model_rank(model):
    return (
        1 if model["candidate"] else 0,
        model["switches"],
        model["informative_bp"],
        min(model["parent_a_bp"], model["parent_b_bp"]),
    )


def build_blocks(windows, seq_len, label_key, score_key, margin_key):
    if not windows:
        return []
    boundaries = []
    mids = [row["mid"] for row in windows]
    for idx, row in enumerate(windows):
        if idx == 0:
            tile_start = 1
        else:
            tile_start = int(math.floor((mids[idx - 1] + mids[idx]) / 2.0)) + 1
        if idx == len(windows) - 1:
            tile_end = seq_len
        else:
            tile_end = int(math.floor((mids[idx] + mids[idx + 1]) / 2.0))
        boundaries.append((tile_start, tile_end))
    blocks = []
    current = None
    for row, (tile_start, tile_end) in zip(windows, boundaries):
        label = row[label_key]
        if current is None or current["label"] != label:
            if current is not None:
                blocks.append(finalize_block(current))
            current = {
                "label": label,
                "start": tile_start,
                "end": tile_end,
                "scores": [row[score_key]],
                "margins": [row[margin_key]],
                "n_windows": 1,
            }
        else:
            current["end"] = tile_end
            current["scores"].append(row[score_key])
            current["margins"].append(row[margin_key])
            current["n_windows"] += 1
    if current is not None:
        blocks.append(finalize_block(current))
    return blocks


def finalize_block(block):
    block["mean_score"] = sum(block["scores"]) / len(block["scores"])
    block["mean_margin"] = sum(block["margins"]) / len(block["margins"])
    block["span_bp"] = block["end"] - block["start"] + 1
    return block


def collect_candidate_rows(rec, donor_candidates, model):
    top_donor_labels = [short_label(parse_header(donor["header"])) for _, donor in donor_candidates[:3]]
    parent_a_label = short_label(model["parent_a"]) if model["parent_a"] else ""
    parent_b_label = short_label(model["parent_b"]) if model["parent_b"] else ""
    summary = []
    for block in model["strong_blocks"]:
        donor_meta = model["parent_a"] if block["label"] == "PARENT_A" else model["parent_b"]
        summary.append(
            f"{block['start']}-{block['end']}:{short_label(donor_meta)}"
        )
    return [{
        "recipient": short_label(rec),
        "recipient_type": rec["type"],
        "recipient_length": len(rec["seq"]),
        "recipient_nonN_frac": round(rec["non_n_frac"], 4),
        "candidate": "yes" if model["candidate"] else "no",
        "parent_a": parent_a_label,
        "parent_b": parent_b_label,
        "n_strong_blocks": len(model["strong_blocks"]),
        "switches": model["switches"],
        "informative_bp": model["informative_bp"],
        "informative_frac": round(model["informative_frac"], 4),
        "parent_a_bp": model["parent_a_bp"],
        "parent_b_bp": model["parent_b_bp"],
        "parent_a_frac": round(model["parent_a_frac"], 4),
        "parent_b_frac": round(model["parent_b_frac"], 4),
        "top_donors": ";".join(top_donor_labels),
        "block_summary": ";".join(summary),
    }]


def plot_candidate(rec, model, coords_map, out_png):
    seq_len = len(rec["seq"])
    fig = plt.figure(figsize=(14, 4.8))
    gs = fig.add_gridspec(3, 1, height_ratios=[0.9, 1.4, 0.7], hspace=0.22)
    ax_gene = fig.add_subplot(gs[0, 0])
    ax_block = fig.add_subplot(gs[1, 0], sharex=ax_gene)
    ax_score = fig.add_subplot(gs[2, 0], sharex=ax_gene)

    draw_gene_track(ax_gene, rec["type"], coords_map.get(rec["type"], []), seq_len)
    draw_block_track(ax_block, rec, model, seq_len)
    draw_score_track(ax_score, model, seq_len)

    title = (
        f"{rec['patient']} {rec['sample_id']} {rec['site']} {rec['type']} {rec['date']}  "
        f"2-parent mosaic screening"
    )
    fig.suptitle(title, fontsize=14, y=0.98)
    fig.savefig(out_png, dpi=220, bbox_inches="tight")
    plt.close(fig)


def draw_gene_track(ax, typ, genes, seq_len):
    ax.set_xlim(1, seq_len)
    ax.set_ylim(0, 1)
    ax.set_yticks([])
    ax.set_ylabel("Genes", fontsize=10)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    baseline_y = 0.35
    ax.hlines(baseline_y, 1, seq_len, color="black", linewidth=0.6)
    gene_colors = {
        "E6": "#d73027",
        "E7": "#f46d43",
        "E1": "#74add1",
        "E2": "#4575b4",
        "E4": "#fee090",
        "E5": "#fdae61",
        "L2": "#66bd63",
        "L1": "#1a9850",
        "URR": "#bdbdbd",
    }
    if not genes:
        ax.text(0.01, 0.75, f"{typ}: no gene coordinates", transform=ax.transAxes, fontsize=9)
        return
    for gene, start, end in genes:
        gene_base = gene.split("^")[0]
        color = gene_colors.get(gene_base, "#cccccc")
        ax.add_patch(
            Rectangle(
                (start, 0.2),
                end - start + 1,
                0.35,
                facecolor=color,
                edgecolor="black",
                linewidth=0.5,
            )
        )
        ax.text((start + end) / 2, 0.67, gene, ha="center", va="bottom", fontsize=8)


def color_for_label(label):
    if label == "LOW_INFO":
        return "#e0e0e0"
    if label == "AMBIG":
        return "#fddbc7"
    if label == "PARENT_A":
        return "#1f78b4"
    if label == "PARENT_B":
        return "#ff7f00"
    return "#bdbdbd"


def draw_block_track(ax, rec, model, seq_len):
    ax.set_xlim(1, seq_len)
    ax.set_ylim(0, 1)
    ax.set_yticks([])
    ax.set_ylabel("Parents", fontsize=10)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    y = 0.32
    h = 0.38
    for block in model["blocks"]:
        color = color_for_label(block["label"])
        ax.add_patch(
            Rectangle(
                (block["start"], y),
                block["span_bp"],
                h,
                facecolor=color,
                edgecolor="black",
                linewidth=0.4,
            )
        )
        if block["label"] in {"PARENT_A", "PARENT_B"} and block["span_bp"] >= max(700, seq_len * 0.07):
            donor_meta = model["parent_a"] if block["label"] == "PARENT_A" else model["parent_b"]
            ax.text(
                (block["start"] + block["end"]) / 2,
                y + h / 2,
                f"{donor_meta['sample_id']}/{donor_meta['type']}",
                ha="center",
                va="center",
                fontsize=7.5,
            )
    ax.text(
        0.01,
        0.92,
        f"recipient: {rec['sample_id']}/{rec['site']}/{rec['type']}",
        transform=ax.transAxes,
        fontsize=9,
        ha="left",
    )
    if model["parent_a"] and model["parent_b"]:
        ax.text(
            0.99,
            0.92,
            f"A={short_label(model['parent_a'])} | B={short_label(model['parent_b'])}",
            transform=ax.transAxes,
            fontsize=8.5,
            ha="right",
        )


def draw_score_track(ax, model, seq_len):
    xs = []
    y_a = []
    y_b = []
    y_gap = []
    for row in model["windows"]:
        mid = row["mid"]
        xs.append(mid)
        y_a.append(row["score_parent_a"])
        y_b.append(row["score_parent_b"])
        y_gap.append(row["score_gap"])
    ax.plot(xs, y_a, color="#1f78b4", linewidth=1.0, label="parent A")
    ax.plot(xs, y_b, color="#ff7f00", linewidth=1.0, label="parent B")
    ax.plot(xs, y_gap, color="#636363", linewidth=0.9, label="gap")
    ax.set_ylim(0, 1.02)
    ax.set_ylabel("Score", fontsize=10)
    ax.set_xlabel("Recipient genome position (bp)", fontsize=10)
    ax.grid(axis="y", color="#d9d9d9", linewidth=0.5)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(frameon=False, loc="upper right", fontsize=8)


def main():
    args = parse_args()
    outdir = Path(args.outdir)
    plot_dir = outdir / "plots"
    outdir.mkdir(parents=True, exist_ok=True)
    plot_dir.mkdir(parents=True, exist_ok=True)

    coords_map = {}
    coords_map.update(load_msk_coords(args.msk_meta))
    coords_map.update(load_pave_coords(args.pave_gff_dir))

    records = []
    for header, seq in read_fasta(args.fasta):
        meta = parse_header(header)
        meta["seq"] = seq
        meta["non_n_frac"] = non_n_fraction(seq)
        meta["global_kmers"] = kmer_set(seq, args.k)
        records.append(meta)

    summary_rows = []
    window_rows = []
    candidate_plots = []

    for rec in records:
        donor_candidates, model = scan_recipient(rec, records, args)
        summary_rows.extend(collect_candidate_rows(rec, donor_candidates, model))
        for row in model["windows"]:
            row_out = dict(row)
            row_out["recipient"] = short_label(rec)
            row_out["recipient_header"] = rec["header"]
            window_rows.append(row_out)
        if model["candidate"]:
            plot_path = plot_dir / (
                f"{rec['patient']}_{rec['sample_id']}_{rec['site']}_{rec['type']}_mosaic_screen.png"
            )
            plot_candidate(rec, model, coords_map, plot_path)
            candidate_plots.append((model["switches"], plot_path))

    summary_rows.sort(key=lambda x: (x["candidate"] != "yes", -x["switches"], -x["informative_bp"], x["recipient"]))

    with (outdir / "candidate_summary.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "recipient",
                "recipient_type",
                "recipient_length",
                "recipient_nonN_frac",
                "candidate",
                "parent_a",
                "parent_b",
                "n_strong_blocks",
                "switches",
                "informative_bp",
                "informative_frac",
                "parent_a_bp",
                "parent_b_bp",
                "parent_a_frac",
                "parent_b_frac",
                "top_donors",
                "block_summary",
            ],
        )
        writer.writeheader()
        writer.writerows(summary_rows)

    with (outdir / "window_best_donor.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "recipient",
                "recipient_header",
                "window_index",
                "start",
                "end",
                "mid",
                "valid_frac",
                "kmer_count",
                "parent_a",
                "parent_b",
                "score_parent_a",
                "score_parent_b",
                "chosen_parent",
                "chosen_score",
                "score_gap",
            ],
        )
        writer.writeheader()
        writer.writerows(window_rows)

    with (outdir / "run_params.txt").open("w") as handle:
        handle.write(f"fasta={args.fasta}\n")
        handle.write(f"window={args.window}\n")
        handle.write(f"step={args.step}\n")
        handle.write(f"k={args.k}\n")
        handle.write(f"top_donors={args.top_donors}\n")
        handle.write(f"min_global_score={args.min_global_score}\n")
        handle.write(f"min_local_score={args.min_local_score}\n")
        handle.write(f"min_margin={args.min_margin}\n")
        handle.write(f"min_block_windows={args.min_block_windows}\n")
        handle.write(f"min_parent_frac={args.min_parent_frac}\n")
        handle.write(f"n_sequences={len(records)}\n")

    if len(candidate_plots) > args.max_plots:
        candidate_plots.sort(reverse=True)
        keep = {path for _, path in candidate_plots[: args.max_plots]}
        for _, path in candidate_plots[args.max_plots :]:
            if path.exists():
                path.unlink()


if __name__ == "__main__":
    main()
